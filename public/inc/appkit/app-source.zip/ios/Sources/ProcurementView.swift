import SwiftUI

struct DeviceRow: Decodable, Identifiable {
    let id: Int; let deviceName: String; let category: String?; let status: String
    let authorizedAmount: Double?; let clientName: String; let clientId: Int
    private enum CodingKeys: String, CodingKey { case id, deviceName, category, status, authorizedAmount, clientName, clientId }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        id = try c.decode(Int.self, forKey: .id)
        deviceName = (try? c.decode(String.self, forKey: .deviceName)) ?? ""
        category = try? c.decodeIfPresent(String.self, forKey: .category)
        status = (try? c.decode(String.self, forKey: .status)) ?? ""
        authorizedAmount = try? c.decodeIfPresent(Double.self, forKey: .authorizedAmount)
        clientName = (try? c.decode(String.self, forKey: .clientName)) ?? ""
        clientId = (try? c.decode(Int.self, forKey: .clientId)) ?? 0
    }
}
struct DeviceRowsResponse: Decodable { let requests: [DeviceRow] }
struct DeviceQuote: Decodable, Identifiable { let id: Int; let vendor: String; let amount: Double; let quoteRef: String?; let notes: String? }
struct DeviceRequest: Decodable {
    let id: Int; let clientName: String; let deviceName: String; let category: String?
    let justification: String?; let status: String; let fundingSource: String?; let authNumber: String?
    let authorizedAmount: Double?; let selectedQuoteId: Int?; let poNumber: String?
    let deliveredAt: String?; let trainedAt: String?; let serial: String?
    var authorizedAt: String?; var orderedAt: String?; var warrantyUntil: String?
    /// The reason given when it was denied or cancelled (4.37.0, S4), shown as "Note: …".
    var notes: String?
}

/// device_request_update's reply (4.37.0 adds the server's sentence and, for a close, the note).
struct DeviceUpdateReply: Decodable { let status: String?; let message: String?; let notes: String? }

/// ai_draft type justification's reply (4.37.0, S5): the text merged as the website does (at
/// most 4,000 characters), the draft alone, and whether it stopped early or was shortened.
struct JustificationDraftReply: Decodable { let text: String; let draft: String?; let truncated: Bool?; let shortened: Bool? }
struct DeviceRequestResponse: Decodable { let request: DeviceRequest; let quotes: [DeviceQuote] }

var deviceCategories: [String] { FormOptions.list("device_request_categories", ["Braille Display", "Screen Reader", "Magnifier / CCTV", "AAC Device", "Tablet / Phone", "Computer", "Hearing / Amplification", "Switch / Access", "Software License", "Other"]) }

struct ProcurementView: View {
    @EnvironmentObject var api: API
    @State private var rows: [DeviceRow] = []
    /// Set once a list has loaded, so "No device requests yet." is never claimed before then.
    @State private var loaded = false
    @State private var error: String?
    @State private var showNew = false
    /// A sheet's success message, announced once the sheet has gone (see announceAfterDismiss).
    @State private var sheetResult: String?

    var body: some View {
        List {
            if let error { ErrorBanner(message: error).listRowSeparator(.hidden) }
            if loaded && rows.isEmpty {
                Text("No device requests yet.").foregroundStyle(Color.secondaryText)
            } else if !loaded && error == nil {
                ProgressView("Loading device requests…")
            }
            ForEach(rows) { r in
                NavigationLink {
                    DeviceRequestDetail(id: r.id, onChanged: { Task { await load() } })
                } label: {
                    VStack(alignment: .leading, spacing: 3) {
                        Text(r.deviceName).font(.body.weight(.semibold))
                        Text("\(r.clientName)\(r.category != nil ? " · \(r.category!)" : "")").font(.caption).foregroundStyle(Color.secondaryText)
                        Text(r.status).font(.caption2.weight(.semibold)).foregroundStyle(Color.brand)
                    }
                }
            }
        }
        .navigationTitle("Procurement")
        .refreshable { await load() }
        .task { await load() }
        .toolbar { ToolbarItem(placement: .primaryAction) { Button { showNew = true } label: { Image(systemName: "plus") }.accessibilityLabel("Add device request") } }
        .sheet(isPresented: $showNew, onDismiss: announceSheetResult) {
            DeviceNewSheet { sheetResult = "Request created."; Task { await load() } }
        }
    }
    private func announceSheetResult() {
        if let message = sheetResult { announceAfterDismiss(message) }
        sheetResult = nil
    }
    private func load() async {
        do { error = nil; let r: DeviceRowsResponse = try await api.call("device_requests"); rows = r.requests; loaded = true }
        catch { showFormError(error.localizedDescription, in: &self.error) }
    }
}

struct DeviceRequestDetail: View {
    @EnvironmentObject var api: API
    let id: Int
    let onChanged: () -> Void
    @State private var req: DeviceRequest?
    @State private var quotes: [DeviceQuote] = []
    @State private var error: String?
    @State private var action: DeviceAction?
    @State private var addingQuote = false
    @State private var pendingClose: DeviceClose?
    /// Deny or cancel, asked in a sheet with the reason (4.37.0, S4).
    @State private var closing: DeviceClose?
    /// A sheet's success message, announced once the sheet has gone (see announceAfterDismiss).
    @State private var sheetResult: String?
    /// After a Pick, VoiceOver is put on the chosen quote: its Pick button is gone by then.
    @AccessibilityFocusState private var focusedQuote: Int?
    @Environment(\.dynamicTypeSize) private var typeSize

    var body: some View {
        List {
            if let error { ErrorBanner(message: error).listRowSeparator(.hidden) }
            if let r = req {
                Section {
                    LabeledContent("Device", value: r.deviceName)
                    LabeledContent("Client", value: r.clientName)
                    LabeledContent("Status", value: r.status)
                    if let f = r.fundingSource, !f.isEmpty { LabeledContent("Funding", value: f) }
                    if let a = r.authNumber, !a.isEmpty { LabeledContent("Auth #", value: a) }
                    if let amt = r.authorizedAmount { LabeledContent("Authorized amount", value: money(amt)) }
                    if let d = r.authorizedAt, !d.isEmpty { LabeledContent("Authorized on", value: formatDate(d)) }
                    if let po = r.poNumber, !po.isEmpty { LabeledContent("PO #", value: po) }
                    if let d = r.orderedAt, !d.isEmpty { LabeledContent("Ordered on", value: formatDate(d)) }
                    if let d = r.deliveredAt, !d.isEmpty { LabeledContent("Delivered on", value: formatDate(d)) }
                    if let s = r.serial, !s.isEmpty { LabeledContent("Serial", value: s) }
                    if let d = r.warrantyUntil, !d.isEmpty { LabeledContent("Warranty until", value: formatDate(d)) }
                    if let d = r.trainedAt, !d.isEmpty { LabeledContent("Training completed", value: formatDate(d)) }
                    if let n = r.notes, !n.isEmpty { Text("Note: \(n)") }
                }
                if let j = r.justification, !j.isEmpty {
                    Section("Justification of need") { Text(j).font(.callout) }
                }
                // 4.37.0 (S4): the funding justification letter, as procurement.php's download.
                Section {
                    NavigationLink("Justification letter") {
                        BuiltDocumentView(navigationTitle: "Justification letter", action: "device_letter", query: ["id": String(id)], noun: "letter",
                                          note: ["Trained", "Denied", "Cancelled"].contains(r.status) ? nil : "Change the justification on the request, then open the letter again.")
                    }
                }
                Section("Quotes") {
                    ForEach(quotes) { q in
                        // At accessibility text sizes the vendor, amount and Pick button stack, so
                        // the vendor column is not squeezed into a narrow strip beside them.
                        let layout = typeSize.isAccessibilitySize
                            ? AnyLayout(VStackLayout(alignment: .leading, spacing: 6)) : AnyLayout(HStackLayout())
                        layout {
                            VStack(alignment: .leading) {
                                Text(q.vendor)
                                if let n = q.notes, !n.isEmpty { Text(n).font(.caption).foregroundStyle(Color.secondaryText) }
                            }
                            if !typeSize.isAccessibilitySize { Spacer() }
                            Text(money(q.amount)).font(.callout)
                            if r.selectedQuoteId == q.id {
                                Image(systemName: "checkmark.seal.fill").foregroundStyle(Color.brandTeal)
                                    .accessibilityLabel("Recommended quote")
                            } else if r.status != "Trained" && r.status != "Denied" && r.status != "Cancelled" {
                                // A large control: the regular bordered capsule is under 44 points tall.
                                Button("Pick") {
                                    Task { await update(["op": "select_quote", "quote_id": q.id], done: "\(q.vendor) quote recommended.", focusQuote: q.id) }
                                }
                                .buttonStyle(.bordered).controlSize(.large)
                                .accessibilityLabel("Pick \(q.vendor) quote")
                                .accessibilityInputLabels(["Pick", "Pick \(q.vendor) quote"])
                            }
                        }
                        // VoiceOver: one stop per quote (vendor, notes, amount, whether it is the
                        // recommended one); Pick is on the Actions rotor.
                        .accessibilityElement(children: VoiceOverRows.children)
                        .accessibilityLabel([q.vendor, q.notes.flatMap { $0.isEmpty ? nil : $0 }, money(q.amount),
                                             r.selectedQuoteId == q.id ? "Recommended quote" : nil]
                            .compactMap { $0 }.joined(separator: ", "))
                        .accessibilityActions {
                            if r.selectedQuoteId != q.id && r.status != "Trained" && r.status != "Denied" && r.status != "Cancelled" {
                                Button("Pick") {
                                    Task { await update(["op": "select_quote", "quote_id": q.id], done: "\(q.vendor) quote recommended.", focusQuote: q.id) }
                                }
                            }
                        }
                        .accessibilityFocused($focusedQuote, equals: q.id)
                    }
                    // The server refuses a new quote on a closed request (reopen it first).
                    if r.status != "Trained" && r.status != "Denied" && r.status != "Cancelled" {
                        Button { addingQuote = true } label: { Label("Add quote", systemImage: "plus") }
                    }
                }
                if r.status != "Trained" && r.status != "Denied" && r.status != "Cancelled" {
                    // Every step stays available while the request is open, as on the website, so
                    // a skipped or wrong authorization, order or delivery can still be recorded.
                    // The server only ever moves the status forward, never back.
                    Section("Advance") {
                        Button(isSet(r.authorizedAt) ? "Edit authorization" : "Record authorization") { action = .authorize }
                        Button(isSet(r.orderedAt) ? "Edit order" : "Record order") { action = .order }
                        Button(isSet(r.deliveredAt) ? "Edit delivery" : "Record delivery") { action = .deliver }
                        // Closing steps cannot be undone from here (training) or end the request,
                        // so each takes a second, deliberate step.
                        Button("Complete training") { pendingClose = .train }
                        // 4.37.0 (S4): denying or cancelling asks for a reason, as procurement.php's form.
                        Button("Deny", role: .destructive) { closing = .deny }
                        Button("Cancel request", role: .destructive) { closing = .cancel }
                    }
                } else if r.status == "Denied" || r.status == "Cancelled" {
                    Section {
                        Button("Reopen request") { Task { await update(["op": "status", "to": "Requested"], done: "Request reopened.") } }
                    }
                }
            } else if error == nil { ProgressView() }
        }
        .navigationTitle("Device request")
        .navigationBarTitleDisplayMode(.inline)
        .task { await load() }
        // Each of these moves the status on the server, so the list behind is refreshed too.
        .sheet(isPresented: $addingQuote, onDismiss: announceSheetResult) {
            DeviceQuoteSheet(requestId: id) { sheetResult = "Quote added."; Task { await load(); onChanged() } }
        }
        .sheet(item: $action, onDismiss: announceSheetResult) { act in
            if let r = req { DeviceActionSheet(request: r, action: act) { message in sheetResult = message ?? act.savedMessage; Task { await load(); onChanged() } } }
        }
        .sheet(item: $closing, onDismiss: announceSheetResult) { close in
            if let r = req { DeviceCloseSheet(request: r, close: close) { message in sheetResult = message; Task { await load(); onChanged() } } }
        }
        .confirmationDialog(pendingClose?.question ?? "", isPresented: Binding(get: { pendingClose != nil }, set: { if !$0 { pendingClose = nil } }),
                            titleVisibility: .visible) {
            if let close = pendingClose {
                Button(close.button, role: close == .train ? nil : .destructive) {
                    pendingClose = nil
                    Task { await update(close.body, done: close.done) }
                }
            }
            Button("Keep request open", role: .cancel) { pendingClose = nil }
        }
    }

    private func isSet(_ day: String?) -> Bool { !(day ?? "").isEmpty }
    private func announceSheetResult() {
        if let message = sheetResult { announceAfterDismiss(message) }
        sheetResult = nil
    }
    /// True when the request was read; false leaves the error banner saying why.
    @discardableResult private func load() async -> Bool {
        do { error = nil; let r: DeviceRequestResponse = try await api.call("device_request", query: ["id": String(id)]); req = r.request; quotes = r.quotes; return true }
        catch { showFormError(error.localizedDescription, in: &self.error); return false }
    }
    /// `done` says what the step did; the status read back afterwards is added, so the outcome
    /// is heard rather than a generic "updated". `focusQuote` puts VoiceOver on that quote once
    /// the list has been rebuilt.
    private func update(_ body: [String: Any], done: String, focusQuote: Int? = nil) async {
        var b = body; b["id"] = id
        do {
            error = nil
            struct UpdateReply: Decodable { let status: String? }
            let reply: UpdateReply = try await api.call("device_request_update", body: b)
            let reloaded = await load(); onChanged()
            if reloaded, let focusQuote { focusedQuote = focusQuote }
            // 4.34.0: a reopened request goes back to its furthest step, which the server names.
            if body["to"] as? String == "Requested" {
                let status = reply.status ?? (reloaded ? req?.status : nil)
                announceAfterDismiss(status.map { "Request reopened. Status updated to \($0)." } ?? "Request reopened.")
                return
            }
            // Said after the reload and the focus move, so neither cuts it off. The saved step is
            // still reported when the refresh fails; only the status is left out then.
            announceAfterDismiss(reloaded && req != nil ? "\(done) Status: \(req!.status)." : done)
        }
        catch { showFormError(error.localizedDescription, in: &self.error) }
    }
}

enum DeviceAction: String, Identifiable {
    case authorize, order, deliver
    var id: String { rawValue }
    /// Announced once the step's sheet has closed.
    var savedMessage: String {
        switch self {
        case .authorize: return "Authorization saved."
        case .order: return "Order saved."
        case .deliver: return "Delivery saved."
        }
    }
}

/// The closing steps that are confirmed before they are sent.
enum DeviceClose: String, Identifiable {
    case train, deny, cancel
    var id: String { rawValue }
    var question: String {
        switch self {
        case .train: return "Mark training complete and close this request? A trained request cannot be reopened."
        case .deny: return "Mark this request denied? It is closed until someone reopens it."
        case .cancel: return "Cancel this request? It is closed until someone reopens it."
        }
    }
    var button: String {
        switch self {
        case .train: return "Complete training"
        case .deny: return "Mark denied"
        case .cancel: return "Cancel request"
        }
    }
    /// What the step did, announced with the status read back afterwards.
    var done: String {
        switch self {
        case .train: return "Training recorded and request closed."
        case .deny: return "Request denied."
        case .cancel: return "Request cancelled."
        }
    }
    var body: [String: Any] {
        switch self {
        case .train: return ["op": "train"]
        case .deny: return ["op": "status", "to": "Denied"]
        case .cancel: return ["op": "status", "to": "Cancelled"]
        }
    }
}

struct DeviceActionSheet: View {
    @EnvironmentObject var api: API
    @Environment(\.dismiss) private var dismiss
    let request: DeviceRequest; let action: DeviceAction
    /// Given the server's sentence when it sends one (4.37.0: a delivery says whether the device
    /// was added to the loaner inventory).
    let onDone: (String?) -> Void
    /// 4.37.0 (S4): add the delivered device to the loaner inventory (procurement.php's box, off
    /// by default; offered only with the equipment permission, which the server also requires).
    @State private var addToInventory = false
    // Filled from the stored request (as the website's forms are), so recording a step again
    // to correct one detail never blanks the others.
    @State private var text1 = ""; @State private var text2 = ""; @State private var amount = ""
    @State private var warranty = ""
    @State private var date = Date(); @State private var busy = false; @State private var error: String?
    @State private var filled = false
    @State private var askingDiscard = false
    /// The values filled in from the stored request, so only real edits ask before they are discarded.
    @State private var initial: [String] = ["", "", "", ""]
    @State private var initialDate = Date()

    private var hasChanges: Bool {
        filled && ([text1, text2, amount, warranty] != initial || !Calendar.current.isDate(date, inSameDayAs: initialDate))
    }

    var body: some View {
        NavigationStack {
            // The error banner is the form's first row; it is scrolled into view and given
            // VoiceOver focus when a problem is reported (see ErrorFocusForm).
            ErrorFocusForm(inNavigationStack: true, error: error) {
                switch action {
                // Each field keeps a visible name above it: they are filled in from the stored
                // request, and a placeholder alone disappears once a field holds a value.
                case .authorize:
                    CaptionedField(label: "Funding source", text: $text1)
                    CaptionedField(label: "Authorization #", text: $text2)
                    KeyboardCaptionedField(label: "Authorized amount", text: $amount, keyboard: .decimalPad, errorName: "Authorized amount")
                    DatePicker("Authorized on", selection: $date, displayedComponents: .date)
                case .order:
                    CaptionedField(label: "PO #", text: $text1)
                    DatePicker("Ordered on", selection: $date, displayedComponents: .date)
                case .deliver:
                    CaptionedField(label: "Serial #", text: $text1)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    DatePicker("Delivered on", selection: $date, displayedComponents: .date)
                    OptionalDayField(title: "Warranty until", text: $warranty)
                    if api.can("equipment") {
                        Toggle("Also add to the loaner inventory", isOn: $addToInventory)
                    }
                }
            }
            .onAppear {
                guard !filled else { return }
                filled = true
                let r = request
                switch action {
                case .authorize:
                    text1 = r.fundingSource ?? ""; text2 = r.authNumber ?? ""
                    amount = r.authorizedAmount.map { String(format: "%.2f", $0) } ?? ""
                    if let d = r.authorizedAt, let day = ymd(d) { date = day }
                case .order:
                    text1 = r.poNumber ?? ""
                    if let d = r.orderedAt, let day = ymd(d) { date = day }
                case .deliver:
                    text1 = r.serial ?? ""
                    warranty = String((r.warrantyUntil ?? "").prefix(10))
                    if let d = r.deliveredAt, let day = ymd(d) { date = day }
                }
                initial = [text1, text2, amount, warranty]; initialDate = date
            }
            .navigationTitle(action.rawValue.capitalized)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                // Not while saving: the step would still be recorded, with no word of it here.
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { if hasChanges { askingDiscard = true } else { dismiss() } }
                        .disabled(busy)
                }
                ToolbarItem(placement: .confirmationAction) { Button("Save") { Task { await submit() } }.disabled(busy) }
            }
            .discardChangesGuard(hasChanges: hasChanges, busy: busy, question: "Discard your changes to this step?",
                                 asking: $askingDiscard) { dismiss() }
        }
    }
    private func submit() async {
        guard let amountText = checkedAmount(amount) else { showFormError(amountFormatMessage("Authorized amount"), in: &error); return }
        if action == .deliver && !warranty.isEmpty && APIDate.strictDay(warranty) == nil {
            showFormError("Warranty until: choose a valid date.", in: &error); return
        }
        busy = true; error = nil
        let day = APIDate.day(date)
        var b: [String: Any] = ["id": request.id]
        switch action {
        case .authorize: b["op"] = "authorize"; b["funding_source"] = text1; b["auth_number"] = text2; b["authorized_amount"] = amountText; b["authorized_at"] = day
        case .order: b["op"] = "order"; b["po_number"] = text1; b["ordered_at"] = day
        case .deliver:
            b["op"] = "deliver"; b["serial"] = text1; b["delivered_at"] = day; b["warranty_until"] = warranty
            b.merge(deviceDeliverExtras(addToInventory: addToInventory, canEquipment: api.can("equipment"))) { $1 }
        }
        // The presenter announces the result once the sheet has gone (a message posted while it
        // is still open is cut off when it closes).
        do { let r: DeviceUpdateReply = try await api.call("device_request_update", body: b); onDone(r.message); dismiss() }
        catch { busy = false; showFormError(error.localizedDescription, in: &self.error) }
    }
}

/// CaptionedField (ClientEditSheet.swift) for a field that needs its own keyboard, such as a
/// decimal pad for an amount: the name stays visible above the field once it holds a value.
struct KeyboardCaptionedField: View {
    let label: String
    @Binding var text: String
    var keyboard: UIKeyboardType = .default
    /// The name errors about this field start with (see CaptionedField.errorName).
    var errorName: String? = nil
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            // The field itself carries the same name for VoiceOver, so the caption is not repeated.
            Text(label).font(.caption.weight(.semibold)).foregroundStyle(Color.secondaryText).accessibilityHidden(true)
            TextField(label, text: $text).keyboardType(keyboard)
                .modifier(OptionalErrorField(name: errorName))
        }
        .modifier(RowID(id: errorName.map { FormFieldID(name: $0.lowercased()) }))
    }
}

struct DeviceQuoteSheet: View {
    @EnvironmentObject var api: API
    /// Sent as idem_key (4.28.0), so a retry after a lost reply does not save it twice.
    @State private var idem = IdemKey()
    @Environment(\.dismiss) private var dismiss
    let requestId: Int; let onDone: () -> Void
    @State private var vendor = ""; @State private var amount = ""; @State private var ref = ""; @State private var notes = ""
    @State private var busy = false; @State private var error: String?
    @State private var askingDiscard = false

    private var hasChanges: Bool {
        [vendor, amount, ref, notes].contains { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
    }

    var body: some View {
        NavigationStack {
            // The error banner is the form's first row; it is scrolled into view and given
            // VoiceOver focus when a problem is reported (see ErrorFocusForm).
            ErrorFocusForm(inNavigationStack: true, error: error) {
                // Visible names that stay once a field is filled; the required ones say so.
                CaptionedField(label: "Vendor (required)", text: $vendor, errorName: "Vendor")
                KeyboardCaptionedField(label: "Amount (required, digits, like 1250.00)", text: $amount, keyboard: .decimalPad, errorName: "Amount")
                CaptionedField(label: "Quote #", text: $ref)
                CaptionedField(label: "Notes", text: $notes)
            }
            .navigationTitle("Add quote")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                // Not while saving: the quote would still be added, with no word of it here.
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { if hasChanges { askingDiscard = true } else { dismiss() } }
                        .disabled(busy)
                }
                // Left enabled: a missing vendor or amount is explained by the error banner, not a dimmed button.
                ToolbarItem(placement: .confirmationAction) { Button("Add") { Task { await submit() } }.disabled(busy) }
            }
            .discardChangesGuard(hasChanges: hasChanges, busy: busy, question: "Discard this quote?",
                                 asking: $askingDiscard) { dismiss() }
        }
    }
    private func submit() async {
        if vendor.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            showFormError("Vendor: enter the vendor's name.", in: &error); return
        }
        // The server needs the quoted price; said here rather than after a round trip.
        if amount.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            showFormError("Amount: enter the quoted price in digits, like 1250.00.", in: &error); return
        }
        guard let amountText = checkedAmount(amount) else { showFormError(amountFormatMessage("Amount"), in: &error); return }
        busy = true; error = nil
        // The presenter announces the result once the sheet has gone.
        var body: [String: Any] = ["id": requestId, "op": "add_quote", "vendor": vendor, "amount": amountText, "quote_ref": ref, "notes": notes]
        body["idem_key"] = idem.key(for: body)
        do { let _: OKResponse = try await api.call("device_request_update", body: body); idem.answered(); onDone(); dismiss() }
        catch { idem.failed(error); busy = false; showFormError(IdemKey.message(for: error, what: "the quote"), in: &self.error) }
    }
}

struct DeviceNewSheet: View {
    @EnvironmentObject var api: API
    /// Sent as idem_key (4.28.0), so a retry after a lost reply does not save it twice.
    @State private var idem = IdemKey()
    @Environment(\.dismiss) private var dismiss
    let onDone: () -> Void
    @State private var selectedClient: Int?
    @State private var deviceName = ""; @State private var category = deviceCategories.contains("Other") ? "Other" : (deviceCategories.first ?? "Other"); @State private var justification = ""
    @State private var busy = false; @State private var error: String?
    @State private var askingDiscard = false
    /// 4.37.0 (S5): "Draft justification with AI" running, and its notice (incomplete).
    @State private var drafting = false
    @State private var draftNotice: String?

    init(onDone: @escaping () -> Void) {
        self.onDone = onDone
    }

    /// Started from a device recommendation (4.37.0, S6): the client and the justification are
    /// filled in; the person picks the device and category and edits the text.
    init(client: Int, justification: String, onDone: @escaping () -> Void) {
        self.onDone = onDone
        _selectedClient = State(initialValue: client)
        _justification = State(initialValue: justification)
    }

    private var hasChanges: Bool {
        selectedClient != nil || category != "Other"
            || [deviceName, justification].contains { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
    }

    var body: some View {
        NavigationStack {
            // The error banner is the form's first row; it is scrolled into view and given
            // VoiceOver focus when a problem is reported (see ErrorFocusForm).
            ErrorFocusForm(inNavigationStack: true, error: error) {
                NewRecordClientPicker(title: "Client (required)", selection: $selectedClient, errorName: "Client")
                CaptionedField(label: "Device / technology (required)", text: $deviceName, errorName: "Device / technology")
                Picker("Category", selection: $category) { ForEach(deviceCategories, id: \.self) { Text($0) } }
                Section("Justification of need") {
                    TextEditor(text: $justification).frame(minHeight: 80).accessibilityLabel("Justification of need")
                        .disabled(drafting)
                        .errorField("Justification of need")
                    // 4.37.0 (S5): the owner's rule, AI drafts on every staff-written text; the
                    // draft fills an empty field or goes below what was typed, and is edited before
                    // the request is created.
                    if api.aiHas("draft") && selectedClient != nil && !deviceName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                        Button(drafting ? "Drafting…" : "Draft justification with AI") { Task { await draftJustification() } }
                            .disabled(drafting || busy)
                    }
                    if let draftNotice {
                        Label(draftNotice, systemImage: "exclamationmark.triangle").font(.callout.weight(.semibold))
                    }
                }
            }
            .navigationTitle("New request")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                // Not while saving: the request would still be created, with no word of it here.
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { if hasChanges { askingDiscard = true } else { dismiss() } }
                        .disabled(busy)
                }
                // Left enabled: what is missing is explained by the error banner, not a dimmed button.
                ToolbarItem(placement: .confirmationAction) { Button("Create") { Task { await submit() } }.disabled(busy) }
            }
            .discardChangesGuard(hasChanges: hasChanges, busy: busy, question: "Discard this new request?",
                                 asking: $askingDiscard) { dismiss() }
        }
    }
    private func submit() async {
        guard let cid = selectedClient else { showFormError("Client: choose the client this request is for.", in: &error); return }
        if deviceName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            showFormError("Device / technology: enter the device or technology requested.", in: &error); return
        }
        if justification.unicodeScalars.count > 4000 {
            showFormError("Justification of need: use 4,000 characters or fewer (you entered \(websiteCount(justification.unicodeScalars.count))).", in: &error); return
        }
        busy = true; error = nil
        // The presenter announces the result once the sheet has gone.
        var body: [String: Any] = ["client_id": cid, "device_name": deviceName, "category": category, "justification": justification]
        body["idem_key"] = idem.key(for: body)
        var refused: [String: String] = [:]
        do { let _: OKResponse = try await api.call("add_device_request", body: body, refusal: { refused = refusalFields($0) }); idem.answered(); onDone(); dismiss() }
        catch APIError.server(let message) {
            idem.answered(); busy = false
            showFormError(message, in: &self.error, field: refusedFieldName(refused, order: ["client_id", "device_name", "justification"],
                                                                            names: ["client_id": "Client", "device_name": "Device / technology", "justification": "Justification of need"]))
        }
        catch { idem.failed(error); busy = false; showFormError(IdemKey.message(for: error, what: "the device request"), in: &self.error) }
    }

    /// ai_draft type justification (4.37.0, S5). "Drafting…" is said once as it starts and the
    /// result once; the draft never replaces typed text.
    private func draftJustification() async {
        guard let cid = selectedClient, !drafting else { return }
        drafting = true; error = nil; draftNotice = nil
        announce("Drafting…")
        defer { drafting = false }
        var refused: [String: String] = [:]
        do {
            let r: JustificationDraftReply = try await api.call("ai_draft", body: ["type": "justification", "client_id": cid, "device_name": deviceName,
                                                                                   "category": category, "text": justification],
                                                                refusal: { refused = refusalFields($0) })
            // Merged here, below what was typed (never cut or replaced); a text over 4,000
            // characters is refused when the request is created, as the website.
            justification = mergeDraft(justification, r.draft ?? r.text)
            var said = "Justification drafted. Review and edit it before creating the request."
            if r.truncated == true { draftNotice = aiDraftIncomplete; said += " " + aiDraftIncomplete }
            if let left = placeholderNotice(justification) { said += " " + left }
            announce(said)
        } catch APIError.server(let message) {
            showFormError(message, in: &self.error, field: refused["device_name"] != nil ? "Device / technology" : nil)
        } catch {
            showFormError(error.localizedDescription, in: &self.error)
        }
    }
}

/// device_request_update op=deliver's 4.37.0 key (S4): add_to_inventory, sent only with the
/// equipment permission (the server reads it only then too).
func deviceDeliverExtras(addToInventory: Bool, canEquipment: Bool) -> [String: Any] {
    canEquipment ? ["add_to_inventory": addToInventory] : [:]
}

/// Deny or cancel a device request with a reason (4.37.0, S4), as procurement.php's "Close this
/// request as" form: the reason is optional, up to 500 characters, and prefilled with the note
/// kept on the request.
struct DeviceCloseSheet: View {
    @EnvironmentObject var api: API
    @Environment(\.dismiss) private var dismiss
    let request: DeviceRequest
    let close: DeviceClose
    let onDone: (String) -> Void
    @State private var reason = ""
    @State private var filled = false
    @State private var busy = false
    @State private var error: String?

    private var to: String { close == .deny ? "Denied" : "Cancelled" }

    var body: some View {
        NavigationStack {
            ErrorFocusForm(inNavigationStack: true, error: error) {
                Section {
                    CaptionedField(label: "Reason (optional; up to 500 characters)", text: $reason, lines: 2...6, errorName: "Reason")
                    Text("It is closed until someone reopens it.")
                }
                Section {
                    Button(busy ? "Saving…" : close.button, role: .destructive) { Task { await submit() } }.disabled(busy)
                    Button("Keep request open") { dismiss() }.disabled(busy)
                }
            }
            .navigationTitle(deviceCloseTitle(device: request.deviceName, to: to))
            .navigationBarTitleDisplayMode(.inline)
            .interactiveDismissDisabled(busy)
            .onAppear { if !filled { filled = true; reason = request.notes ?? "" } }
        }
    }

    private func submit() async {
        if reason.unicodeScalars.count > 500 { showFormError("Reason: use 500 characters or fewer.", in: &error, field: "Reason"); return }
        busy = true; error = nil
        var refused: [String: String] = [:]
        do {
            let r: DeviceUpdateReply = try await api.call("device_request_update", body: ["id": request.id, "op": "status", "to": to, "notes": reason],
                                                          refusal: { refused = refusalFields($0) })
            onDone(r.message ?? "Status updated to \(to).")
            dismiss()
        } catch {
            busy = false
            showFormError(error.localizedDescription, in: &self.error, field: refused["notes"] != nil ? "Reason" : nil)
        }
    }
}

/// The deny/cancel sheet's title (4.37.0, S4): "Close <device> as denied?"
func deviceCloseTitle(device: String, to: String) -> String {
    "Close \(device) as \(to == "Denied" ? "denied" : "cancelled")?"
}

func money(_ v: Double) -> String {
    let f = NumberFormatter(); f.numberStyle = .currency; f.currencyCode = "USD"
    return f.string(from: NSNumber(value: v)) ?? String(format: "$%.2f", v)
}
