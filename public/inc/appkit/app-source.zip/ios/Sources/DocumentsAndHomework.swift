import SwiftUI
import QuickLook

// MARK: - Documents

struct ClientDocument: Decodable, Identifiable {
    let id: Int
    let category: String
    let title: String
    let origName: String
    let createdAt: String
    /// Shown on the client's portal, and on their VR counselor's (4.25.0; false from an older server).
    var portalShared = false
    var counselorShared = false
    /// "portal", "counselor" or "staff"; nil when not known.
    var uploadedVia: String?
    private enum CodingKeys: String, CodingKey { case id, category, title, origName, createdAt, portalShared, counselorShared, uploadedVia }
    init(id: Int, category: String = "", title: String, origName: String = "", createdAt: String = "") {
        self.id = id; self.category = category; self.title = title; self.origName = origName; self.createdAt = createdAt
    }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        id = try c.decode(Int.self, forKey: .id)
        category = (try? c.decode(String.self, forKey: .category)) ?? ""
        title = (try? c.decode(String.self, forKey: .title)) ?? ""
        origName = (try? c.decode(String.self, forKey: .origName)) ?? ""
        createdAt = (try? c.decode(String.self, forKey: .createdAt)) ?? ""
        portalShared = (try? c.decode(Bool.self, forKey: .portalShared)) ?? ((try? c.decode(Int.self, forKey: .portalShared)) ?? 0 != 0)
        counselorShared = (try? c.decode(Bool.self, forKey: .counselorShared)) ?? ((try? c.decode(Int.self, forKey: .counselorShared)) ?? 0 != 0)
        uploadedVia = try? c.decodeIfPresent(String.self, forKey: .uploadedVia)
    }
    /// A Resource or a file the client shared is always on their portal (turning it off is not offered).
    var alwaysOnPortal: Bool { category == "Resource" || category == "Shared by client" }
    /// Who can see it outside the agency, in words.
    var sharingText: String {
        switch (portalShared, counselorShared) {
        case (true, true): return "Shared with the client and the counselor"
        case (true, false): return "Shared with the client"
        case (false, true): return "Shared with the counselor"
        default: return "Not shared"
        }
    }
}

/// The reply to share_document: where the document is shown now.
struct ShareDocumentResult: Decodable {
    let portalShared: Bool?
    let counselorShared: Bool?
}

struct DocumentsResponse: Decodable { let documents: [ClientDocument] }

/// The Documents section's download and preview. A List calls onDisappear on a section's
/// rows as soon as they scroll out of view, so the download is not tied to the rows: it runs
/// on while the person scrolls, and is cancelled only when this object is released with the
/// client screen (the running request holds no reference to it).
@MainActor
final class DocumentDownloader: ObservableObject {
    @Published private(set) var downloading = false
    @Published var previewURL: URL?
    @Published var error: String?
    private var previewDirectory: URL?
    private let running = RunningTask()

    /// Not main-actor bound, so the task can be cancelled from deinit.
    private final class RunningTask {
        var task: Task<Void, Never>?
        deinit { task?.cancel() }
    }

    func open(_ document: ClientDocument, api: API) {
        // One at a time: a second tap is said, not silently dropped.
        guard !downloading else {
            announce("A document is already downloading. Wait for it to open.")
            return
        }
        downloading = true; error = nil
        announce("Downloading \(document.title).")
        var components = URLComponents(url: API.base, resolvingAgainstBaseURL: false)!
        components.queryItems = [
            URLQueryItem(name: "action", value: "download_document"),
            URLQueryItem(name: "id", value: String(document.id)),
        ]
        let sessionToken = api.token
        var request = URLRequest(url: components.url!)
        API.identifyApp(&request)
        request.setValue("Bearer \(sessionToken)", forHTTPHeaderField: "Authorization")
        running.task = Task { [weak self] in
            let reply = try? await API.session.data(for: request)
            // The client screen closed meanwhile: the document is not written anywhere.
            guard let self, !Task.isCancelled else { return }
            self.finish(document, reply: reply, api: api, sessionToken: sessionToken)
        }
    }

    private func finish(_ document: ClientDocument, reply: (Data, URLResponse)?, api: API, sessionToken: String) {
        defer { downloading = false }
        // A phone reported lost (4.27.0): wiped and signed out, as for every other request.
        if let (data, response) = reply, let refusal = api.wipeIfReportedLost(response, data: data, sessionToken: sessionToken) {
            showFormError(refusal, in: &error)
            return
        }
        // Signed out (or another account) meanwhile: nothing is written.
        guard api.token == sessionToken else { return }
        guard let reply else {
            showFormError("Could not download \(document.title). Check your connection and try again.", in: &error)
            return
        }
        let (data, response) = reply
        if (response as? HTTPURLResponse)?.statusCode == 401 {
            // The sign-in opens over the app; the download is not retried, so say so.
            showFormError("Your session ended. Sign in again, then open \(document.title) again.", in: &error)
            api.expireSession()
            return
        }
        if API.isRedirect(response) {
            showFormError("Could not download \(document.title). " + API.redirectRefused, in: &error)
            return
        }
        guard (response as? HTTPURLResponse)?.statusCode == 200 else {
            // The server says why (the file is missing, the document is gone, or the client is
            // not on this caseload), so a lasting problem doesn't sound like one worth retrying.
            let reason = (try? JSONDecoder().decode(APIErrorResponse.self, from: data))?.error?
                .trimmingCharacters(in: .whitespacesAndNewlines)
            showFormError("Could not download \(document.title)." + ((reason?.isEmpty == false) ? " \(reason!)" : ""), in: &error)
            return
        }
        removePreview()
        do {
            let dir = PreviewStore.directory.appendingPathComponent(UUID().uuidString, isDirectory: true)
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            previewDirectory = dir
            // A message's file is known by its title only: the server's file name is used then.
            let named = document.origName.isEmpty ? (response.suggestedFilename ?? "") : document.origName
            let filename = (named as NSString).lastPathComponent
            let fileURL = dir.appendingPathComponent(filename.isEmpty || filename == "." || filename == ".." ? "document" : filename)
            try data.write(to: fileURL, options: [.atomic, .completeFileProtection])
            previewURL = fileURL
        } catch {
            removePreview()
            showFormError("Could not download \(document.title).", in: &self.error)
        }
    }

    func removePreview() {
        if let dir = previewDirectory { try? FileManager.default.removeItem(at: dir) }
        previewDirectory = nil
    }
}

struct DocumentsSection: View {
    @EnvironmentObject var api: API
    let clientId: Int
    /// Changed by the client screen when it refreshes (after an upload, pull-to-refresh), so
    /// this section reloads with it.
    var reloadToken = 0
    /// The server can share documents (4.25.0); an older one shows no sharing at all.
    var sharing = false
    @State private var documents: [ClientDocument] = []
    @State private var loaded = false
    @StateObject private var downloader = DocumentDownloader()
    @State private var error: String?

    var body: some View {
        Section(loaded ? "Documents (\(documents.count))" : "Documents") {
            if let error { ErrorBanner(message: error) }
            if let downloadError = downloader.error { ErrorBanner(message: downloadError) }
            if !loaded && error == nil {
                // Always a row while loading, so the section is never just a heading.
                ProgressView("Loading documents…")
            } else if loaded && documents.isEmpty {
                Text("No documents on file.").foregroundStyle(Color.secondaryText)
            }
            ForEach(documents) { document in
                VStack(alignment: .leading, spacing: 6) {
                    Button {
                        downloader.open(document, api: api)
                    } label: {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(document.title).font(.body.weight(.medium)).foregroundStyle(.primary)
                            Text("\(document.category) · \(formatDateTime(document.createdAt))")
                                .font(.caption).foregroundStyle(Color.secondaryText)
                            // Who can see it, in words (4.25.0).
                            if sharing {
                                Text(document.sharingText).font(.caption).foregroundStyle(Color.secondaryText)
                            }
                        }
                        .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
                        .contentShape(Rectangle())
                    }
                    // Plain, so only this part of the row opens it: the row has a second control.
                    .buttonStyle(.plain)
                    // Sharing is on the Actions rotor and the long-press menu; double-tap still opens it.
                    .contextMenu { shareButtons(document) }
                    .accessibilityActions { shareButtons(document) }
                    // A visible way to change who sees it (4.30.0): the long-press menu was the
                    // only one outside VoiceOver, which has the choices on the Actions rotor.
                    if sharing {
                        Menu { shareChoices(document) } label: {
                            Label("Sharing", systemImage: "person.2")
                        }
                        .buttonStyle(.bordered)
                        .controlSize(.large)
                        .accessibilityLabel("Sharing: \(document.title)")
                        .accessibilityInputLabels(["Sharing", "Sharing \(document.title)"])
                        .accessibilityHidden(UIAccessibility.isVoiceOverRunning)
                    }
                }
            }
        }
        .task(id: reloadToken) { await load() }
        .quickLookPreview($downloader.previewURL)
        .onChange(of: downloader.previewURL) { url in
            if url == nil { downloader.removePreview() }
        }
        // A preview still open when this section goes away (sign-out, expired session) keeps
        // its file; PreviewStore.sweep() removes it at sign-out and at the next launch.
        // A download still running carries on (this also fires when the rows scroll out of
        // view); DocumentDownloader cancels it when the client screen itself closes.
        .onDisappear {
            if downloader.previewURL == nil { downloader.removePreview() }
        }
        .overlay { if downloader.downloading { ProgressView().accessibilityLabel("Downloading document") } }
    }

    @ViewBuilder
    private func shareButtons(_ document: ClientDocument) -> some View {
        if sharing {
            shareChoices(document)
        }
    }

    @ViewBuilder
    private func shareChoices(_ document: ClientDocument) -> some View {
        if !document.alwaysOnPortal {
            Button(document.portalShared ? "Stop sharing with client" : "Share with client") {
                Task { await share(document, with: "portal", on: !document.portalShared) }
            }
        }
        Button(document.counselorShared ? "Stop sharing with counselor" : "Share with counselor") {
            Task { await share(document, with: "counselor", on: !document.counselorShared) }
        }
    }

    /// Shows the document on (or takes it off) the client's portal or their counselor's.
    private func share(_ document: ClientDocument, with: String, on: Bool) async {
        do {
            error = nil
            let r: ShareDocumentResult = try await api.call("share_document", body: [
                "client_id": clientId, "document_id": document.id, "with": with, "on": on,
            ])
            if let i = documents.firstIndex(where: { $0.id == document.id }) {
                documents[i].portalShared = r.portalShared ?? (with == "portal" ? on : documents[i].portalShared)
                documents[i].counselorShared = r.counselorShared ?? (with == "counselor" ? on : documents[i].counselorShared)
            }
            let who = with == "portal" ? "the client" : "the counselor"
            announce(on ? "\(document.title) shared with \(who)." : "\(document.title) is no longer shared with \(who).")
        } catch {
            showFormError("Could not change sharing for \(document.title). \(error.localizedDescription)", in: &self.error)
        }
    }

    private func load() async {
        do {
            let response: DocumentsResponse = try await api.call("documents", query: ["client_id": String(clientId)])
            documents = response.documents
            loaded = true
            error = nil
        } catch {
            // A load replaced by a newer one, or the screen closing, is not a failure to report.
            guard !Task.isCancelled else { return }
            showFormError(error.localizedDescription, in: &self.error)
        }
    }
}

// MARK: - Homework

struct HomeworkItem: Decodable, Identifiable {
    let id: Int
    let title: String
    let instructions: String?
    let assignedAt: String
    let dueDate: String?
    let status: String
    let trackTitle: String
    let trackId: Int
    let editToken: String?
    /// When the client marked it done on the portal; it stays Assigned until staff verify it.
    let clientReportedAt: String?
}

extension HomeworkItem {
    /// "Client reported done Oct 8, 2026" for an Assigned item the client marked done.
    var clientReportText: String? {
        guard status == "Assigned", let reported = clientReportedAt, !reported.isEmpty else { return nil }
        return "Client reported done \(formatDate(reported))"
    }
}

struct HomeworkResponse: Decodable { let homework: [HomeworkItem] }

struct HomeworkSection: View {
    @EnvironmentObject var api: API
    let clientId: Int
    let tracks: [Track]
    /// Changed by the client screen when it refreshes (after a note with homework,
    /// pull-to-refresh), so this section reloads with it.
    var reloadToken = 0
    @State private var homework: [HomeworkItem] = []
    @State private var loaded = false
    @State private var showingAssign = false
    @State private var editing: HomeworkItem?
    @State private var confirmingComplete: HomeworkItem?
    @State private var error: String?
    /// The result of the assign or edit sheet, said once the sheet has closed.
    @State private var sheetResult: String?
    /// After Mark completed leaves with the reload, VoiceOver is put on that item's status.
    @AccessibilityFocusState private var focusedStatus: Int?

    var body: some View {
        Section("Homework") {
            if let error { ErrorBanner(message: error) }
            if !loaded && error == nil {
                // Always a row while loading, so the section never reads as "nothing assigned".
                ProgressView("Loading homework…")
            } else if loaded && homework.isEmpty {
                Text("No homework assigned.").foregroundStyle(Color.secondaryText)
            }
            ForEach(homework) { item in
                VStack(alignment: .leading, spacing: 3) {
                    HStack {
                        Text(item.title).font(.body.weight(.medium))
                        Spacer()
                        // The status is in words; the symbol's colour only decorates it.
                        HStack(spacing: 4) {
                            Image(systemName: item.status == "Completed" ? "checkmark.circle.fill" : "clock")
                                .foregroundStyle(item.status == "Completed" ? Color.brandTeal : Color.orange)
                                .accessibilityHidden(true)
                            Text(item.status).foregroundStyle(.primary)
                        }
                        .font(.caption.weight(.semibold))
                    }
                    // In words (as the track page's badge): the status stays Assigned until verified.
                    if let report = item.clientReportText {
                        Text(report).font(.caption.weight(.semibold)).foregroundStyle(.primary)
                    }
                    if let instructions = item.instructions, !instructions.isEmpty {
                        Text(instructions).font(.callout).foregroundStyle(Color.secondaryText)
                    }
                    Text("\(item.trackTitle)\(item.dueDate != nil ? " · due \(formatDate(item.dueDate))" : "")")
                        .font(.caption).foregroundStyle(Color.secondaryText)
                    // Named per item, so the Buttons rotor and Voice Control tell them apart; the
                    // visible words are a spoken name too (Voice Control). "With AI" only when the
                    // edit form offers AI drafting.
                    let editText = api.aiHas("draft") ? "Edit or revise with AI" : "Edit"
                    // At least 44 points to touch (4.26.0 audit: the bare text was 28 by 19).
                    Button { editing = item } label: {
                        Text(editText).font(.callout)
                            .frame(minWidth: 44, minHeight: 44, alignment: .leading)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.borderless)
                        .accessibilityLabel("\(editText): \(item.title)")
                        .accessibilityInputLabels([editText, "Edit", "Edit \(item.title)"])
                    if queuedHomework.contains(item.id) {
                        Text("Completed, waiting to send").font(.callout).foregroundStyle(Color.secondaryText)
                    } else if item.status == "Assigned" {
                        // Completing can't be undone and takes it off the client portal: asked first.
                        Button("Mark completed") { confirmingComplete = item }
                            .font(.callout)
                            .buttonStyle(.bordered)
                            .controlSize(.large)   // at least 44 points tall
                            .padding(.top, 2)
                            .accessibilityLabel("Mark \(item.title) completed")
                            .accessibilityInputLabels(["Mark completed", "Mark \(item.title) completed"])
                            .confirmationDialog("Mark “\(item.title)” completed? It disappears from the client portal.",
                                                isPresented: Binding(get: { confirmingComplete?.id == item.id },
                                                                     set: { if !$0 { confirmingComplete = nil } }),
                                                titleVisibility: .visible) {
                                Button("Mark completed") { Task { await complete(item) } }
                                Button("Cancel", role: .cancel) {}
                            }
                    }
                }
                .padding(.vertical, 2)
                // One VoiceOver stop per item: its details read in order, and Edit and Mark
                // completed in the Actions rotor (the same code as the visible buttons, so
                // Mark completed still asks first).
                .accessibilityElement(children: VoiceOverRows.children)
                .accessibilityLabel(homeworkSpoken(item))
                .accessibilityFocused($focusedStatus, equals: item.id)
                .accessibilityActions {
                    if item.status == "Assigned" {
                        Button("Mark completed") { confirmingComplete = item }
                    }
                    Button(api.aiHas("draft") ? "Edit or revise with AI" : "Edit") { editing = item }
                }
            }
            if !tracks.filter({ $0.status == "Active" }).isEmpty {
                Button {
                    showingAssign = true
                } label: {
                    Label("Assign homework", systemImage: "plus")
                }
            }
        }
        .task(id: reloadToken) { await load() }
        // Reloaded however the edit sheet closes (saved or cancelled), so the next edit starts
        // from the current version and its edit token — not a stale one the server refuses.
        // A sheet's result is said once it has closed (closing it cut off a message said inside).
        .sheet(item: $editing, onDismiss: {
            announceSheetResult()
            Task { await load() }
        }) { item in
            AssignHomeworkSheet(tracks: tracks, item: item, clientId: clientId) { message in sheetResult = message }
        }
        .sheet(isPresented: $showingAssign, onDismiss: announceSheetResult) {
            AssignHomeworkSheet(tracks: tracks.filter { $0.status == "Active" }) { message in
                sheetResult = message
                Task { await load() }
            }
        }
    }

    /// The item as VoiceOver reads it: title, status, the client's report, instructions, track and due date.
    private func homeworkSpoken(_ item: HomeworkItem) -> String {
        var parts = [item.title, item.status]
        if let report = item.clientReportText { parts.append(report) }
        if let instructions = item.instructions, !instructions.isEmpty { parts.append(instructions) }
        parts.append("Track: \(item.trackTitle)")
        if item.dueDate != nil { parts.append("Due \(formatDate(item.dueDate))") }
        return parts.joined(separator: ", ")
    }

    private func announceSheetResult() {
        if let message = sheetResult { announceAfterDismiss(message) }
        sheetResult = nil
    }

    private func load() async {
        do {
            let response: HomeworkResponse = try await api.call("homework", query: ["client_id": String(clientId)])
            homework = response.homework
            loaded = true
            error = nil
        } catch {
            // A load replaced by a newer one, or the screen closing, is not a failure to report.
            guard !Task.isCancelled else { return }
            showFormError(error.localizedDescription, in: &self.error)
        }
    }

    /// Homework marked completed without a signal, waiting in the offline queue (4.8.0).
    @State private var queuedHomework: Set<Int> = []

    private func complete(_ item: HomeworkItem) async {
        // Cleared first so a repeat of the same failure is shown (and announced) again.
        error = nil
        do {
            let _: OKResponse = try await api.call("complete_homework", body: ["id": item.id])
            // The reload takes away the Mark completed button VoiceOver was on: VoiceOver is put
            // on the item's status, then the result is said (said before, it was cut off).
            await load()
            try? await Task.sleep(nanoseconds: 150_000_000)   // let the reloaded rows appear first
            if homework.contains(where: { $0.id == item.id }) { focusedStatus = item.id }
            announceAfterDismiss("\(item.title) marked completed.")
        } catch APIError.network {
            // No signal (4.8.0): marking homework done is safe to send again, so it waits on the phone.
            do {
                try api.enqueue("complete_homework", body: ["id": item.id], label: "Homework done: " + String(item.title.prefix(40)))
                queuedHomework.insert(item.id)
                announce("No signal. \(item.title) will be marked completed when you are back online.")
            } catch { showFormError(error.localizedDescription, in: &self.error) }
        } catch { showFormError(error.localizedDescription, in: &self.error) }
    }
}

struct AssignHomeworkSheet: View {
    @EnvironmentObject var api: API
    /// Sent as idem_key (4.28.0), so a retry after a lost reply does not save it twice.
    @State private var idem = IdemKey()
    @Environment(\.dismiss) private var dismiss
    let tracks: [Track]
    var item: HomeworkItem? = nil
    /// The client the edited item belongs to, so the latest version can be fetched again.
    var clientId: Int = 0
    /// The result to tell the person, said by the section once the sheet has gone.
    let onDone: (String) -> Void

    /// The edit token of the version this form holds (refreshed by "Reload the latest version").
    @State private var editToken: String?
    /// "Client reported done …" for the version this form holds (refreshed with it).
    @State private var clientReport: String?
    @State private var selectedTrack: Int?
    @State private var title = ""
    @State private var instructions = ""
    @State private var hasDue = true
    @State private var dueDate = Calendar.current.date(byAdding: .day, value: 7, to: Date()) ?? Date()
    @State private var busy = false
    @State private var error: String?
    @State private var askingDiscard = false
    /// The form's fields as it opened (after an edited item is filled in), to tell whether
    /// anything was changed.
    @State private var opened: [String]?

    private var values: [String] {
        [selectedTrack.map(String.init) ?? "", title, instructions, hasDue ? APIDate.day(dueDate) : ""]
    }
    /// The start of the server's refusal when the assignment changed since this form opened
    /// (at_homework_update: "This assignment changed. Reload it before saving.").
    private static let changedRefusal = "This assignment changed."
    private var hasChanges: Bool { opened.map { $0 != values } ?? false }

    var body: some View {
        NavigationStack {
            ErrorFocusForm(inNavigationStack: true, error: error) {
                // After the "This assignment changed" refusal, the current version can be loaded
                // here instead of only by leaving the client screen. Only then: it replaces what
                // was typed, so it is not offered after other errors, where it looked like a retry.
                if item != nil && clientId > 0 && error?.hasPrefix(Self.changedRefusal) == true {
                    Button("Reload the latest version") { Task { await reloadItem() } }
                        .disabled(busy)
                        .accessibilityHint("Replaces your changes with the saved version.")
                }
                // The client's report is kept by a due-date change, but cleared by a new title or
                // new instructions (at_homework_update): said before they are changed.
                if let clientReport {
                    Text("\(clientReport). Changing the title or instructions clears the client's report, so they would have to report it again; changing only the due date keeps it.")
                        .font(.callout)
                }
                Picker("Training track (required)", selection: $selectedTrack) {
                    Text("Choose…").tag(nil as Int?)
                    ForEach(tracks) { track in
                        Text(track.title).tag(track.id as Int?)
                    }
                }
                .disabled(item != nil)
                    .errorField("Training track")
                // Each name stays visible above its field once it holds text (a placeholder alone
                // disappears); the field carries the same name for VoiceOver, so the caption is hidden.
                CaptionedField(label: "Assignment title (required)", text: $title, prompt: "Assignment title", errorName: "Assignment title")
                CaptionedField(label: "Instructions", text: $instructions, lines: 3...8)
                if api.aiHas("draft") {
                    ATAIDraftPanel(kind: "homework", targets: [ATDraftTarget(key: "instructions", label: "Instructions"), ATDraftTarget(key: "title", label: "Title")], context: ["track_id": selectedTrack.map(String.init) ?? "", "title": title, "instructions": instructions]) { key, text in
                        if key == "title" { title = text } else { instructions = text }
                    }
                }
                Toggle("Due date", isOn: $hasDue)
                if hasDue {
                    DatePicker("Due", selection: $dueDate, displayedComponents: .date)
                }
                Text("Shows on the client's portal page until completed.")
                    .font(.caption).foregroundStyle(Color.secondaryText)
            }
            .navigationTitle(item == nil ? "Assign homework" : "Edit homework")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { if hasChanges { askingDiscard = true } else { dismiss() } }
                        .disabled(busy)
                }
                ToolbarItem(placement: .confirmationAction) {
                    // Not dimmed for a missing track or title: submit() says which is needed.
                    Button(item == nil ? "Assign" : "Save") { Task { await submit() } }
                        .disabled(busy)
                }
            }
            .discardChangesGuard(hasChanges: hasChanges, busy: busy,
                                 question: item == nil ? "Discard this homework?" : "Discard your changes to this homework?",
                                 asking: $askingDiscard) { dismiss() }
             .task {
                guard opened == nil else { return }
                if let item {
                    selectedTrack = item.trackId; title = item.title; instructions = item.instructions ?? ""; hasDue = item.dueDate != nil
                    if let date = item.dueDate.flatMap(APIDate.parseDay) { dueDate = date }
                    editToken = item.editToken
                    clientReport = item.clientReportText
                } else if tracks.count == 1 { selectedTrack = tracks.first?.id }
                opened = values
            }
        }
    }

    /// Replaces the form with the assignment as it is now on the server (and its edit token).
    private func reloadItem() async {
        guard let item else { return }
        busy = true; defer { busy = false }
        do {
            let response: HomeworkResponse = try await api.call("homework", query: ["client_id": String(clientId)])
            guard let fresh = response.homework.first(where: { $0.id == item.id }) else {
                showFormError("This assignment is no longer listed for the client.", in: &error)
                return
            }
            title = fresh.title
            instructions = fresh.instructions ?? ""
            hasDue = fresh.dueDate != nil
            if let date = fresh.dueDate.flatMap(APIDate.parseDay) { dueDate = date }
            editToken = fresh.editToken
            clientReport = fresh.clientReportText
            error = nil
            announce("Latest version loaded. Make your changes again, then save.")
        } catch {
            showFormError(error.localizedDescription, in: &self.error)
        }
    }

    private func submit() async {
        guard let trackId = selectedTrack else {
            showFormError("Training track: choose the track this homework belongs to.", in: &error)
            return
        }
        guard !title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            showFormError("Assignment title: enter a title for the homework.", in: &error)
            return
        }
        busy = true; error = nil
        do {
            var body: [String: Any] = ["track_id": trackId, "title": title, "instructions": instructions, "due_date": hasDue ? APIDate.day(dueDate) : ""]
            if let item { body["id"] = item.id; body["edit_token"] = editToken ?? item.editToken ?? "" }
            if item == nil { body["idem_key"] = idem.key(for: body) }
            let _: OKResponse = try await api.call(item == nil ? "assign_homework" : "at_homework_update", body: body)
            idem.answered()
            // Said by the Homework section once this sheet has closed (closing it would cut it off).
            onDone(item == nil ? "Homework assigned." : "Homework updated.")
            dismiss()
        } catch {
            idem.failed(error)
            showFormError(item == nil ? IdemKey.message(for: error, what: "the homework") : error.localizedDescription, in: &self.error)
            busy = false
        }
    }
}
