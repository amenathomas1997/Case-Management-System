import SwiftUI

/// One invoice on the read-only list (the website's Invoices page).
struct InvoiceItem: Decodable, Identifiable {
    let id: Int
    let invoiceNumber: String
    let status: String
    let clientId: Int
    let clientName: String
    let trackTitle: String
    let authNumber: String?
    let fundingAgency: String?
    let hours: Double
    let totalAmount: Double
    let paidAmount: Double?
    /// What is still owed: the total until it is paid, then any short-paid remainder.
    let balance: Double
    let shortPaid: Bool
    let daysOutstanding: Int?
    let createdAt: String
    let submittedAt: String?
    let paidAt: String?
    let canOpenClient: Bool
    /// 3.0.34 servers: the amount written off, the due date from the payment terms, and why
    /// a Denied or Void invoice was closed (absent from older servers).
    let writtenOff: Double
    let dueDate: String?
    let closedReason: String?
    private enum CodingKeys: String, CodingKey {
        case id, invoiceNumber, status, clientId, clientName, trackTitle, authNumber, fundingAgency, hours, totalAmount
        case paidAmount, balance, shortPaid, daysOutstanding, createdAt, submittedAt, paidAt, canOpenClient
        case writtenOff, dueDate, closedReason
    }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        id = try c.decode(Int.self, forKey: .id)
        invoiceNumber = (try? c.decode(String.self, forKey: .invoiceNumber)) ?? ""
        status = (try? c.decode(String.self, forKey: .status)) ?? ""
        clientId = (try? c.decode(Int.self, forKey: .clientId)) ?? 0
        clientName = (try? c.decode(String.self, forKey: .clientName)) ?? ""
        trackTitle = (try? c.decode(String.self, forKey: .trackTitle)) ?? ""
        authNumber = try? c.decodeIfPresent(String.self, forKey: .authNumber)
        fundingAgency = try? c.decodeIfPresent(String.self, forKey: .fundingAgency)
        hours = (try? c.decode(Double.self, forKey: .hours)) ?? 0
        totalAmount = (try? c.decode(Double.self, forKey: .totalAmount)) ?? 0
        paidAmount = try? c.decodeIfPresent(Double.self, forKey: .paidAmount)
        balance = (try? c.decode(Double.self, forKey: .balance)) ?? 0
        shortPaid = (try? c.decode(Bool.self, forKey: .shortPaid)) ?? false
        daysOutstanding = try? c.decodeIfPresent(Int.self, forKey: .daysOutstanding)
        createdAt = (try? c.decode(String.self, forKey: .createdAt)) ?? ""
        submittedAt = try? c.decodeIfPresent(String.self, forKey: .submittedAt)
        paidAt = try? c.decodeIfPresent(String.self, forKey: .paidAt)
        canOpenClient = (try? c.decode(Bool.self, forKey: .canOpenClient)) ?? false
        writtenOff = (try? c.decode(Double.self, forKey: .writtenOff)) ?? 0
        dueDate = try? c.decodeIfPresent(String.self, forKey: .dueDate)
        closedReason = try? c.decodeIfPresent(String.self, forKey: .closedReason)
    }
}

struct InvoiceAgingRow: Decodable { let fundingAgency: String; let count: Int; let amount: Double; let oldestDays: Int? }

struct InvoicesResponse: Decodable {
    let invoices: [InvoiceItem]
    let total: Int
    let page: Int
    let pages: Int
    let outstanding: [InvoiceAgingRow]
    let unbilled: Double
}

extension InvoiceItem {
    var statusText: String {
        if status == "Denied" || status == "Void" { return status + ((closedReason ?? "").isEmpty ? "" : ": \(closedReason!)") }
        if shortPaid { return "\(status == "Paid" ? "Paid" : "Part-paid"): \(String(format: "$%.2f", balance)) still owed" }
        if status == "Submitted", let days = daysOutstanding { return "Submitted, \(days) day\(days == 1 ? "" : "s") outstanding" }
        return status
    }
    var datesText: String {
        var parts = ["Created \(formatDate(createdAt))"]
        if let submittedAt { parts.append("submitted \(formatDate(submittedAt))") }
        if let dueDate, status == "Submitted" { parts.append("due \(formatDate(dueDate))") }
        if let paidAt { parts.append("last payment \(formatDate(paidAt))") }
        if writtenOff > 0 { parts.append(String(format: "$%.2f written off", writtenOff)) }
        return parts.joined(separator: ", ")
    }
    var spoken: String {
        var parts = ["Invoice \(invoiceNumber)", clientName, String(format: "$%.2f", totalAmount), statusText]
        if balance > 0 && status != "Paid" { parts.append(String(format: "balance $%.2f", balance)) }
        parts.append("\(trackTitle), authorization \(authNumber ?? "none")")
        if let fundingAgency, !fundingAgency.isEmpty { parts.append(fundingAgency) }
        parts.append(hoursSpoken(hours))
        parts.append(datesText)
        return parts.joined(separator: ". ")
    }
}

/// The invoice list: status, amount, balance and dates, filtered by status, with what each
/// funding agency still owes. A draft can be marked submitted today (4.0.0); other billing
/// actions stay on the website.
struct InvoicesView: View {
    @EnvironmentObject var api: API
    @State private var data: InvoicesResponse?
    @State private var error: String?
    @State private var status = ""
    @State private var page = 1
    /// The draft waiting for a yes before it is marked submitted (4.0.0).
    @State private var pendingSubmit: InvoiceItem?
    /// The submit sheet's result, said (or shown, for a refusal) once the sheet has gone.
    @State private var submitResult: String?
    @State private var submitRefused: String?

    var body: some View {
        List {
            if let error { ErrorBanner(message: error).listRowSeparator(.hidden) }
            Section {
                Picker("Show", selection: $status) {
                    Text("All invoices").tag("")
                    Text("Draft").tag("Draft")
                    Text("Submitted").tag("Submitted")
                    Text("Paid").tag("Paid")
                    Text("Denied").tag("Denied")
                    Text("Void").tag("Void")
                }
                Text("A draft can be marked submitted here (its Mark submitted button, a swipe, or the Actions rotor). Recording payments and write-offs, and closing denied invoices, are on the website.")
                    .font(.callout).foregroundStyle(Color.secondaryText)
            }
            if let d = data {
                Section {
                    LabeledContent("Unbilled work", value: String(format: "$%.2f", d.unbilled))
                    ForEach(Array(d.outstanding.enumerated()), id: \.offset) { _, a in
                        LabeledContent(a.fundingAgency.isEmpty ? "No agency" : a.fundingAgency,
                                       value: String(format: "$%.2f, %d invoice%@%@", a.amount, a.count, a.count == 1 ? "" : "s",
                                                     a.oldestDays.map { ", oldest \($0) days" } ?? ""))
                    }
                    if d.outstanding.isEmpty { Text("Nothing is outstanding.").foregroundStyle(Color.secondaryText) }
                } header: {
                    Text("Outstanding by funding agency").font(.headline).foregroundStyle(.primary).textCase(nil)
                        .accessibilityAddTraits(.isHeader)
                }
                Section {
                    if d.invoices.isEmpty { Text("No invoices.").foregroundStyle(Color.secondaryText) }
                    ForEach(d.invoices) { inv in invoiceRow(inv) }
                    if d.pages > 1 {
                        HStack {
                            Button("Newer") { page = max(1, page - 1); Task { await load() } }.disabled(page <= 1)
                            Spacer()
                            Button("Older") { page = min(d.pages, page + 1); Task { await load() } }.disabled(page >= d.pages)
                        }
                        .buttonStyle(.borderless)
                        .frame(minHeight: 44)
                    }
                } header: {
                    Text(d.pages > 1 ? "Invoices (page \(d.page) of \(d.pages), \(d.total) in all)" : "Invoices (\(d.total))")
                        .font(.headline).foregroundStyle(.primary).textCase(nil)
                        .accessibilityAddTraits(.isHeader)
                }
            } else if error == nil {
                ProgressView("Loading invoices…")
            }
        }
        .navigationTitle("Invoices")
        // The Show picker's choice is not cut short at the accessibility text sizes.
        .modifier(ReadablePickers(inNavigationStack: true))
        // 4.34.0: asks for the date it was sent, as the website does (the due date follows from it).
        .sheet(item: $pendingSubmit, onDismiss: afterSubmitSheet) { inv in
            SubmitInvoiceSheet(invoice: inv) { message, refused in
                submitResult = message
                if refused { submitRefused = message }
                Task { await load() }
            }
        }
        .onChange(of: status) { _ in page = 1; Task { await load(announceView: true) } }
        .refreshable { await load() }
        .task { await load() }
    }

    /// One invoice, opening the client's record when allowed; a draft offers Mark submitted.
    @ViewBuilder
    private func invoiceRow(_ inv: InvoiceItem) -> some View {
        let row = VStack(alignment: .leading, spacing: 3) {
            HStack {
                Text(inv.invoiceNumber).font(.body.weight(.semibold))
                Spacer()
                Text(String(format: "$%.2f", inv.totalAmount)).font(.body.monospacedDigit())
            }
            Text(inv.clientName).font(.callout)
            Text(inv.statusText).font(.caption).foregroundStyle(inv.shortPaid ? Color.alertRed : Color.secondaryText)
            Text("\(inv.trackTitle) · Authorization \(inv.authNumber ?? "none")").font(.caption).foregroundStyle(Color.secondaryText)
            Text(inv.datesText).font(.caption).foregroundStyle(Color.secondaryText)
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(inv.spoken)
        Group {
            if inv.canOpenClient {
                NavigationLink { ClientDetailView(clientId: inv.clientId) } label: { row }
            } else {
                row
            }
        }
        .modifier(DraftSubmitActions(isDraft: inv.status == "Draft") { pendingSubmit = inv })
        // A visible single-tap way (4.30.0), as well as the swipe: Switch Control, Voice Control
        // and anyone who never finds the swipe had none. VoiceOver has it on the row's Actions
        // rotor, so it is not a second stop there.
        if inv.status == "Draft" {
            Button { pendingSubmit = inv } label: {
                Label("Mark submitted", systemImage: "paperplane").frame(minHeight: 44)
            }
            .buttonStyle(.bordered)
            .controlSize(.large)
            .accessibilityLabel("Mark invoice \(inv.invoiceNumber) submitted")
            .accessibilityInputLabels(["Mark submitted", "Mark invoice \(inv.invoiceNumber) submitted"])
            .accessibilityHidden(UIAccessibility.isVoiceOverRunning)
        }
    }

    /// Said once the sheet has gone (a message said while it closes is cut off).
    private func afterSubmitSheet() {
        if let refused = submitRefused {
            submitRefused = nil; submitResult = nil
            showFormError(refused, in: &error)
            return
        }
        if let message = submitResult { announceAfterDismiss(message) }
        submitResult = nil
    }

    private func load(announceView: Bool = false) async {
        let wanted = status
        var query = ["page": String(page)]
        if !wanted.isEmpty { query["status"] = wanted }
        do {
            error = nil
            let r: InvoicesResponse = try await api.call("invoices", query: query)
            guard wanted == status else { return }
            data = r
            if announceView { announce("\(r.total) \(wanted.isEmpty ? "" : wanted.lowercased() + " ")invoice\(r.total == 1 ? "" : "s").") }
        } catch {
            guard wanted == status else { return }
            showFormError(error.localizedDescription, in: &self.error)
        }
    }
}

/// Mark submitted, as a swipe and on the Actions rotor, on a draft invoice only.
private struct DraftSubmitActions: ViewModifier {
    let isDraft: Bool
    let action: () -> Void
    func body(content: Content) -> some View {
        if isDraft {
            content
                .swipeActions { Button("Mark submitted", action: action).tint(.brandTeal) }
                .accessibilityAction(named: "Mark submitted", action)
        } else {
            content
        }
    }
}

/// Mark a draft invoice submitted (4.34.0): the date it went to the funder, from the day it was
/// created to today, as the website asks; the due date is set from it by the payment terms.
struct SubmitInvoiceSheet: View {
    @EnvironmentObject var api: API
    @Environment(\.dismiss) private var dismiss
    let invoice: InvoiceItem
    /// The message to say, and whether it is a refusal (the list is reloaded either way).
    let onDone: (String, Bool) -> Void
    @State private var submittedOn = Date()
    @State private var busy = false
    @State private var error: String?
    @State private var idem = IdemKey()

    private var earliest: Date {
        APIDate.strictDay(String(invoice.createdAt.prefix(10))).map { min($0, Date()) } ?? Calendar.current.startOfDay(for: Date())
    }

    var body: some View {
        NavigationStack {
            ErrorFocusForm(inNavigationStack: true, error: error) {
                Text("Mark invoice \(invoice.invoiceNumber) as submitted to the funder? Its due date is set from the payment terms.")
                DatePicker("Date submitted", selection: $submittedOn, in: earliest...Date(), displayedComponents: .date)
                    .errorField("Date submitted")
            }
            .navigationTitle("Mark submitted")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() }.disabled(busy) }
                ToolbarItem(placement: .confirmationAction) {
                    Button(busy ? "Saving…" : "Mark submitted") { Task { await submit() } }.disabled(busy)
                }
            }
        }
    }

    private func submit() async {
        busy = true; error = nil
        struct Reply: Decodable { let submittedOn: String?; let dueDate: String? }
        var body: [String: Any] = ["id": invoice.id, "submitted_on": APIDate.day(submittedOn)]
        body["idem_key"] = idem.key(for: body)
        var status409 = false
        var dateRefused = false
        do {
            let r: Reply = try await api.call("submit_invoice", body: body, refusal: { reply in
                // 4.34.0: the server marks a draft that changed meanwhile (its 409) with changed:true.
                status409 = (reply["changed"] as? Bool) == true
                let fields = (reply["errors"] as? [String: String]) ?? [:]
                dateRefused = fields["submitted_on"] != nil
            })
            idem.answered()
            let on = formatDate(r.submittedOn ?? APIDate.day(submittedOn))
            let due = (r.dueDate ?? "").isEmpty ? "" : "; it is due \(formatDate(r.dueDate))"
            onDone("Invoice \(invoice.invoiceNumber) marked submitted on \(on)\(due).", false)
            dismiss()
        } catch {
            idem.failed(error)
            busy = false
            if status409 {
                // Someone else changed it: the list is reloaded and the reason said there.
                onDone(error.localizedDescription, true)
                dismiss()
                return
            }
            // About the date: by its error key, or (the server sends none today) by its words,
            // "The date sent must be from the day the invoice was created to today."
            let aboutDate = dateRefused || error.localizedDescription.contains("date sent")
            showFormError(aboutDate ? error.localizedDescription : IdemKey.message(for: error, what: "the invoice"),
                          in: &self.error, field: aboutDate ? "Date submitted" : nil)
        }
    }
}
