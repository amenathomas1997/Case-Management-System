import SwiftUI
import WidgetKit

/// GET schedule, with the counts 3.0.12 servers add: the server sends only the next
/// upcomingLimit upcoming sessions, and upcomingTotal says how many there are in all.
/// Both optional, so an older server still decodes.
private struct ScheduleListResponse: Decodable {
    let sessions: [Session]
    let upcomingTotal: Int?
    let upcomingLimit: Int?
    private enum CodingKeys: String, CodingKey { case sessions, upcomingTotal, upcomingLimit }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        sessions = try c.decode([Session].self, forKey: .sessions)
        upcomingTotal = try? c.decodeIfPresent(Int.self, forKey: .upcomingTotal)
        upcomingLimit = try? c.decodeIfPresent(Int.self, forKey: .upcomingLimit)
    }
}

struct ScheduleView: View {
    @EnvironmentObject var api: API
    @EnvironmentObject private var lock: AppLock
    @Environment(\.dynamicTypeSize) private var typeSize
    @Environment(\.openURL) private var openURL
    @State private var sessions: [Session] = []
    @AppStorage("scheduleMineOnly") private var mineOnly = false
    /// How many upcoming sessions exist in all, and how many the server sends (nil from an
    /// older server).
    @State private var upcomingTotal: Int?
    @State private var upcomingLimit: Int?
    @State private var error: String?
    @State private var confirmation: String?
    @State private var showingNewSession = false
    @State private var showingLogHours = false
    @State private var signingSession: Session?
    /// A session being moved to a new time (3.0.43).
    @State private var movingSession: Session?
    /// Asking before the rest of a series, or a whole group, is cancelled.
    @State private var cancellingMore: (session: Session, action: String)?
    /// 4.35.0: booking a group session, and recording a group's attendance. `groupSupported`
    /// is nil until the server has answered group_choices once; false (a server before 4.35.0)
    /// hides both buttons.
    @State private var showingGroupSession = false
    @State private var recordingGroup: GroupRef?
    @State private var groupSupported: Bool?
    /// The first case note to write after a group's attendance was recorded, opened once that
    /// sheet has closed.
    @State private var groupNoteAfterSheet: SessionNoteRequest?
    /// 4.35.0: the case notes to write after a group's attendance, walked through in turn as the
    /// website does ("Next: Jane Doe, 2 of 3", with Skip for now), and the one open now.
    @State private var groupNotes: [SessionNoteTarget] = []
    @State private var groupNoteIndex = 0
    @State private var loaded = false
    /// Set while the list is the copy kept on this phone (the server could not be reached):
    /// when it was saved. Nothing can be changed until a load succeeds.
    @State private var offlineSince: Date?
    /// The client record opened from a session's Actions rotor (4.0.0).
    @State private var openClientId: Int?
    @State private var showingClient = false
    /// Sessions whose outcome (completed, cancelled, no-show) is on its way, so a second tap
    /// can't send it again.
    @State private var completing: Set<Int> = []
    /// Sessions whose check-in is on its way.
    @State private var checkingIn: Set<Int> = []
    /// Check-ins recorded from this screen, by session id: when the server confirmed it (its
    /// time), or Self.offlineCheckIn for one kept on this phone until it syncs. Kept across
    /// reloads, since a server older than 3.0.28 does not report checked_in_at.
    @State private var checkedInLocal: [Int: String] = [:]
    private static let offlineCheckIn = "offline"
    /// A completion (with no track), cancel or no-show waiting for the person to confirm it.
    @State private var pendingOutcome: SessionOutcome?
    /// The result of a sheet (new session, signature), said once the sheet has closed.
    @State private var sheetResult: String?
    /// A signed completion's result: the signature sheet locks the app as it closes, so this is
    /// said once the device owner has unlocked (said under the lock screen, it was lost).
    @State private var resultAfterUnlock: String?
    /// 4.31.0: the case-note editor open for a completed session.
    @State private var noteRequest: SessionNoteRequest?
    /// The note to open once the Complete session sheet has closed, or once the device owner has
    /// unlocked after the client signed.
    @State private var noteAfterSheet: SessionNoteRequest?
    @State private var noteAfterUnlock: SessionNoteRequest?
    /// The editor's result: set when the note was saved (or kept offline).
    @State private var noteSavedMessage: String?
    /// complete_session's retry key per session (4.31.0, sent as idem_key): one for the life of
    /// the Complete session sheet, kept after no answer (or "still being processed"), so trying
    /// again is recognised by the server instead of completing the session twice.
    @State private var completionKeys: [Int: String] = [:]
    /// Completed sessions whose case note is not written yet (notes_to_write); nil from an older
    /// server, which hides the section.
    @State private var notesToWrite: NotesToWriteResponse?
    /// The Notes to write row VoiceOver is put on when the editor is left without saving.
    @AccessibilityFocusState private var focusedNote: Int?
    /// The row VoiceOver moves to after an outcome removes the row it was on.
    @AccessibilityFocusState private var focusedSession: Int?
    /// After a failure, VoiceOver is put on the error banner (see the list's onChange).
    @AccessibilityFocusState private var errorFocused: Bool
    private static let errorRow = "scheduleError"

    /// The session an outcome applies to, and the status it would get.
    struct SessionOutcome {
        let session: Session
        let to: String   // "Completed" (complete_session, no track), "Cancelled" or "No Show" (set_session_status)
    }

    var body: some View {
        NavigationStack {
            ScrollViewReader { proxy in
                List {
                    if let error {
                        ErrorBanner(message: error).listRowSeparator(.hidden)
                            .id(Self.errorRow)
                            .accessibilityFocused($errorFocused)
                    }
                    if let confirmation {
                        Text(confirmation)
                            .font(.callout.weight(.medium))
                            .foregroundStyle(Color.brandTeal)
                            .listRowSeparator(.hidden)
                    }
                    if let offlineSince { OfflineNotice(savedAt: offlineSince).listRowSeparator(.hidden) }
                    if !loaded && error == nil {
                        ProgressView("Loading schedule…")
                    } else if loaded && sessions.isEmpty && error == nil {
                        Text("Nothing scheduled. Use New session to add one.")
                            .foregroundStyle(Color.secondaryText)
                    }
                    // Sessions that have ended but are still Scheduled come first (the server sends
                    // every one of them): each needs an outcome, so its hours are logged or it is closed.
                    Toggle("My sessions only", isOn: $mineOnly)
                    // 4.31.0: completed sessions whose case note is not written yet.
                    let unwritten = notesShown
                    if !unwritten.isEmpty {
                        Section {
                            ForEach(unwritten) { item in
                                NoteToWriteRow(item: item) { openNote(SessionNoteRequest(target: item, arrival: item.contextLine + ".")) }
                                    .accessibilityFocused($focusedNote, equals: item.sessionId)
                            }
                        } header: {
                            Text("Notes to write (\(max(unwritten.count, notesToWrite?.total ?? 0)))")
                        }
                    }
                    let ended = shownSessions.filter { $0.overdue == true }
                    let upcoming = shownSessions.filter { $0.overdue != true }
                    let groups = dayGroups(upcoming)
                    if !ended.isEmpty {
                        Section {
                            ForEach(ended) { session in sessionRow(session) }
                        } header: {
                            Text("Ended — awaiting an outcome (\(ended.count))")
                        } footer: {
                            Text("Mark each one completed, cancelled or a no-show.")
                        }
                    }
                    // Upcoming sessions by day (Today, Tomorrow, Later), each a heading the
                    // VoiceOver rotor can jump to.
                    ForEach(groups, id: \.title) { group in
                        Section {
                            ForEach(group.sessions) { session in sessionRow(session) }
                        } header: {
                            Text("\(group.title) (\(group.sessions.count))")
                        } footer: {
                            // Only the next upcomingLimit are sent: said, so the list is not taken
                            // for every booked session.
                            if group.title == groups.last?.title,
                               let total = upcomingTotal, let limit = upcomingLimit, total > limit {
                                Text("Showing the next \(limit) of \(total) upcoming sessions; the rest are on the website's Schedule.")
                            }
                        }
                    }
                }
                // The banner is the list's first row: a failed outcome (cancel, no-show, completed)
                // from a row further down would otherwise leave it off screen, where a List never
                // draws it (or says it). Scrolled into view once it exists, then VoiceOver is put on it.
                .onChange(of: error) { message in
                    guard let message else { return }
                    claimFormErrorFocus(message)   // VoiceOver is put on the banner, which reads it
                    DispatchQueue.main.async { withAnimation(UIAccessibility.isReduceMotionEnabled ? nil : .default) { proxy.scrollTo(Self.errorRow, anchor: .top) } }
                    Task { @MainActor in
                        try? await Task.sleep(nanoseconds: 400_000_000)
                        errorFocused = true
                    }
                }
            }
            .navigationTitle("Schedule")
            .navigationDestination(isPresented: $showingClient) {
                if let openClientId { ClientDetailView(clientId: openClientId) }
            }
            .confirmationDialog(outcomeQuestion, isPresented: Binding(get: { pendingOutcome != nil },
                                                                      set: { if !$0 { pendingOutcome = nil } }),
                                titleVisibility: .visible, presenting: pendingOutcome) { outcome in
                if outcome.to == "Completed" {
                    Button("Mark completed") { Task { await completeFromList(outcome.session) } }
                } else {
                    Button(outcome.to == "Cancelled" ? "Cancel session" : "Mark no-show", role: .destructive) {
                        Task { await setStatus(outcome.session, to: outcome.to) }
                    }
                }
                Button("Keep it scheduled", role: .cancel) {}
            }
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button { showingNewSession = true } label: {
                        Label("New session", systemImage: "plus")
                    }
                    .disabled(offlineSince != nil)
                }
                // 4.35.0: as the website's "Schedule a group session" form.
                if groupsOffered {
                    ToolbarItem(placement: .primaryAction) {
                        Button { showingGroupSession = true } label: {
                            Label("Schedule a group session", systemImage: "person.3")
                        }
                        .disabled(offlineSince != nil)
                    }
                }
                // Logging hours reads client tracks, which needs the clients
                // permission — hide the button for schedule-only groups.
                if api.can("clients") {
                    ToolbarItem(placement: .primaryAction) {
                        Button { showingLogHours = true } label: {
                            Label("Log hours", systemImage: "clock.badge.checkmark")
                        }
                    }
                }
            }
            .sheet(isPresented: $showingNewSession, onDismiss: announceSheetResult) {
                NewSessionSheet { message in
                    confirmation = message
                    sheetResult = message
                    Task { await load() }
                }
            }
            .sheet(isPresented: $showingLogHours) {
                LogHoursView()
            }
            .sheet(isPresented: $showingGroupSession, onDismiss: announceSheetResult) {
                GroupSessionSheet { message in
                    confirmation = message
                    sheetResult = message
                    Task { await load() }
                }
            }
            .sheet(item: $recordingGroup, onDismiss: afterGroupSheet) { group in
                GroupAttendanceSheet(groupUid: group.id) { message, notes in
                    confirmation = message
                    sheetResult = message
                    if api.can("clients"), !notes.isEmpty {
                        groupNotes = notes
                        groupNoteIndex = 0
                        groupNoteAfterSheet = groupNoteRequest(0, lead: message)
                    }
                    Task { await load() }
                }
            }
            .sheet(item: $movingSession, onDismiss: announceSheetResult) { session in
                MoveSessionSheet(session: session) { message in
                    sheetResult = message
                    Task { await load() }
                }
            }
            .confirmationDialog(cancelMoreQuestion,
                                isPresented: Binding(get: { cancellingMore != nil }, set: { if !$0 { cancellingMore = nil } }), titleVisibility: .visible) {
                Button("Cancel them", role: .destructive) {
                    if let c = cancellingMore { Task { await cancelMore(c.session, action: c.action) } }
                    cancellingMore = nil
                }
                Button("Keep them", role: .cancel) { cancellingMore = nil }
            }
            .sheet(item: $signingSession, onDismiss: afterCompletionSheet) { session in
                // The sheet stays open until the completion is saved, so a failure keeps the
                // client's signature for a retry instead of asking them to sign again.
                // Hours and miles first (staff only), then the client's signature or none: one
                // step records the session, then its case note opens (4.31.0).
                CompleteSessionSheet(session: session) { details, sig, name, outcome in
                    try await complete(session, signature: sig, signedName: name, details: details, outcome: outcome)
                }
            }
            .sheet(item: $noteRequest, onDismiss: afterNoteSheet) { request in
                SessionNoteSheet(request: request) { message in noteSavedMessage = message }
            }
            .refreshable { await load() }
            .task { await load() }
            .task { await probeGroups() }
            .onChange(of: lock.locked) { locked in
                if !locked, let request = noteAfterUnlock {
                    // The client signed and handed the phone back: once the device owner has
                    // unlocked and VoiceOver has settled, the session's case note opens.
                    noteAfterUnlock = nil
                    resultAfterUnlock = nil
                    Task { @MainActor in
                        try? await Task.sleep(nanoseconds: 1_000_000_000)
                        openNote(request)
                    }
                    return
                }
                guard !locked, let message = resultAfterUnlock else { return }
                resultAfterUnlock = nil
                // After the lock screen has gone and VoiceOver has settled on the schedule.
                Task { @MainActor in
                    try? await Task.sleep(nanoseconds: 1_000_000_000)
                    announce(message)
                }
            }
        }
    }

    /// "session with Jane Doe, instructor Sam Lee, on Oct 8, 2026 at 2:00 PM": names the row in
    /// each of its buttons, so the Buttons rotor and Voice Control tell a weekly series apart.
    private func sessionName(_ session: Session) -> String {
        let instructor = (session.instructor ?? "").isEmpty ? nil : session.instructor
        return "session with \(session.client)\(instructor.map { ", instructor \($0)," } ?? "") on \(formatDateTime(session.startAt))"
    }

    /// 4.35.0: the website's questions, naming the session (Cancel the series / the whole group).
    private var cancelMoreQuestion: String {
        guard let c = cancellingMore else { return "" }
        return Self.cancelMoreConfirm(c.action, client: c.session.client, date: formatDateTime(c.session.startAt))
    }

    static func cancelMoreConfirm(_ action: String, client: String, date: String) -> String {
        action == "cancel_group"
            ? "Cancel this group session on \(date) for every client in it? Each client is sent a calendar cancellation."
            : "Cancel this session with \(client) on \(date) and every later session in its weekly series? The client is sent a calendar cancellation."
    }

    /// Whether a server release is 4.35.0 or later ("4.35.0", "4.36"); nil when it can't be read.
    static func supportsGroups(serverVersion: String?) -> Bool? {
        guard let v = serverVersion, !v.isEmpty else { return nil }
        let parts = v.split(separator: ".").map { Int($0.prefix(while: \.isNumber)) ?? 0 }
        guard let major = parts.first else { return nil }
        let minor = parts.count > 1 ? parts[1] : 0
        return major > 4 || (major == 4 && minor >= 35)
    }

    /// Whether this server books groups (4.35.0). The release `me` reported decides (a light
    /// check, as the Android app makes); with none known, group_choices is asked, and only
    /// "Unknown action." (a server before 4.35.0) hides the buttons. Any other failure keeps
    /// them, and the server is asked again the next time.
    private func probeGroups() async {
        if let known = Self.supportsGroups(serverVersion: api.serverVersion) { groupSupported = known; return }
        guard groupSupported == nil else { return }
        do {
            let _: GroupChoicesResponse = try await api.call("group_choices")
            groupSupported = true
        } catch APIError.server(let message) where message == "Unknown action." {
            groupSupported = false
        } catch {
            // Not known: the buttons stay, and the form says what went wrong if it is opened.
        }
    }

    /// The group buttons show unless the server is known not to book groups.
    private var groupsOffered: Bool { groupSupported != false }

    /// The case note for the group's note `index`, saying which it is ("Next: Jane Doe, 1 of 3")
    /// after `lead`; leaving it is Skip for now (the note stays under Notes to write).
    private func groupNoteRequest(_ index: Int, lead: String) -> SessionNoteRequest {
        let t = groupNotes[index]
        return SessionNoteRequest(target: t, arrival: Self.groupNoteArrival(lead: lead, name: t.clientName, index: index, total: groupNotes.count) + " " + t.contextLine + ".",
                                  cancelLabel: "Skip for now")
    }

    static func groupNoteArrival(lead: String, name: String, index: Int, total: Int) -> String {
        (lead.isEmpty ? "" : lead + " ") + "Next: \(name), \(index + 1) of \(total)."
    }

    /// The attendance sheet has closed: the first client's case note opens (as after a single
    /// completion), else the result is said.
    private func afterGroupSheet() {
        guard let request = groupNoteAfterSheet else { announceSheetResult(); return }
        groupNoteAfterSheet = nil
        sheetResult = nil
        Task { @MainActor in
            await loadNotes()
            try? await Task.sleep(nanoseconds: 300_000_000)
            openNote(request)
        }
    }

    private var outcomeQuestion: String {
        guard let outcome = pendingOutcome else { return "" }
        let name = sessionName(outcome.session)
        switch outcome.to {
        case "Completed": return "Mark the \(name) completed? No hours are logged, because no training track is linked. It can't be reopened in the app."
            + (api.can("clients") ? " Its case note opens next." : "")
        case "Cancelled": return "Cancel the \(name)? It is closed without logging any hours."
        default: return "Mark the \(name) as a no-show? It is closed without logging any hours."
        }
    }

    /// Completed sessions with no case note yet: notes_to_write's list, and any Completed
    /// session the schedule itself reports as note_pending (newest first, one row each).
    private var notesShown: [SessionNoteTarget] {
        var rows = notesToWrite?.notes ?? []
        for session in sessions where session.status == "Completed" && session.notePending == true
            && !rows.contains(where: { $0.sessionId == session.id }) {
            if let cid = session.clientId {
                rows.append(SessionNoteTarget(sessionId: session.id, clientId: cid, clientName: session.client,
                                              trackId: session.trackId, sessionDate: String(session.startAt.prefix(10)),
                                              startAt: session.startAt, noteSubject: nil))
            }
        }
        return rows
    }

    /// Opens the case-note editor for a completed session (4.31.0).
    private func openNote(_ request: SessionNoteRequest) {
        noteSavedMessage = nil
        noteRequest = request
    }

    /// The Complete session sheet has closed: the session's case note opens (after the device
    /// owner unlocks, when the client signed), else the result is said as before.
    private func afterCompletionSheet() {
        guard let request = noteAfterSheet else { announceSheetResult(); return }
        noteAfterSheet = nil
        sheetResult = nil
        if lock.locked { noteAfterUnlock = request; return }
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: 300_000_000)
            openNote(request)
        }
    }

    /// The case-note editor has closed: saved, the result is said; left without saving, the
    /// Schedule says so and VoiceOver is put on the session's row under Notes to write.
    private func afterNoteSheet() {
        let closed = noteRequest
        // 4.35.0: after a group, the next client's note opens, saved or skipped, until the last.
        if !groupNotes.isEmpty, closed.map({ c in groupNotes.indices.contains(groupNoteIndex) && groupNotes[groupNoteIndex].sessionId == c.target.sessionId }) == true {
            if groupNoteIndex + 1 < groupNotes.count {
                let lead = noteSavedMessage ?? "Skipped for now: that note stays under Notes to write."
                noteSavedMessage = nil
                groupNoteIndex += 1
                let next = groupNoteRequest(groupNoteIndex, lead: lead)
                Task { @MainActor in
                    await loadNotes()
                    try? await Task.sleep(nanoseconds: 400_000_000)
                    openNote(next)
                }
                return
            }
            groupNotes = []
            groupNoteIndex = 0
        }
        if let message = noteSavedMessage {
            noteSavedMessage = nil
            confirmation = message
            Task { @MainActor in
                await loadNotes()
                announceAfterDismiss(message)
            }
            return
        }
        Task { @MainActor in
            await loadNotes()
            let target = closed?.target
            let listed = target.map { t in notesShown.contains(where: { $0.sessionId == t.sessionId }) } ?? false
            let who = target?.clientName ?? "this client"
            let message = listed
                ? "Case note not written yet. It is listed under Notes to write, with Write it now."
                : "Case note not written yet. Write it from \(who)'s record."
            confirmation = message
            try? await Task.sleep(nanoseconds: 150_000_000)
            if listed, let t = target { focusedNote = t.sessionId }
            announceAfterDismiss(message)
        }
    }

    /// notes_to_write (4.31.0); an older server leaves the section out without a word.
    private func loadNotes() async {
        notesToWrite = await loadNotesToWrite(api)
    }

    private func announceSheetResult() {
        if let message = sheetResult {
            if lock.locked { resultAfterUnlock = message } else { announceAfterDismiss(message) }
        }
        sheetResult = nil
    }

    /// Upcoming sessions grouped by the day they start on this phone: Earlier (started on a past
    /// day, not yet ended), Today, Tomorrow and Later, each in the server's order. Empty groups
    /// are left out; a start that can't be read goes under Later.
    private func dayGroups(_ list: [Session]) -> [(title: String, sessions: [Session])] {
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: Date())
        var buckets: [[Session]] = [[], [], [], []]
        for session in list {
            guard let start = APIDate.parseDateTimeCentral(session.startAt) else { buckets[3].append(session); continue }
            if start < today { buckets[0].append(session) }
            else if calendar.isDateInToday(start) { buckets[1].append(session) }
            else if calendar.isDateInTomorrow(start) { buckets[2].append(session) }
            else { buckets[3].append(session) }
        }
        return zip(["Earlier", "Today", "Tomorrow", "Later"], buckets)
            .filter { !$0.1.isEmpty }
            .map { (title: $0.0, sessions: $0.1) }
    }

    /// The session VoiceOver should land on once `session`'s row has gone: the next one in the
    /// list as shown (ended first, then upcoming by day), else the one before it.
    private func neighbour(of session: Session) -> Int? {
        let shown = shownSessions.filter { $0.overdue == true }
            + dayGroups(shownSessions.filter { $0.overdue != true }).flatMap(\.sessions)
        guard let index = shown.firstIndex(where: { $0.id == session.id }) else { return nil }
        if index + 1 < shown.count { return shown[index + 1].id }
        return index > 0 ? shown[index - 1].id : nil
    }

    /// After the list reloads without `session`, moves VoiceOver to its neighbour (instead of
    /// wherever the platform puts it), then says the result: said before the reload and that
    /// focus move, it was cut off by them.
    private func refocus(after session: Session, next: Int?, saying message: String?) {
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: 150_000_000)   // let the reloaded rows appear first
            if let next, !sessions.contains(where: { $0.id == session.id }),
               sessions.contains(where: { $0.id == next }) {
                focusedSession = next
            }
            if let message { announceAfterDismiss(message) }
        }
    }

    /// Whether the session's start (server time, America/Chicago) has come. A start that can't
    /// be read leaves the choice to the server.
    private func hasStarted(_ session: Session, at now: Date) -> Bool {
        guard let start = APIDate.parseDateTimeCentral(session.startAt) else { return true }
        return start <= now
    }

    /// Check in is offered for today's sessions that have started, or start within 30 minutes,
    /// and are not checked in yet; not for one that has ended (it needs an outcome instead).
    private func canCheckIn(_ session: Session, at now: Date) -> Bool {
        guard session.overdue != true, checkedInText(session) == nil,
              let start = APIDate.parseDateTimeCentral(session.startAt),
              Calendar.current.isDate(start, inSameDayAs: now) else { return false }
        return start <= now.addingTimeInterval(30 * 60)
    }

    /// "Checked in at 2:05 PM", or that the check-in is waiting on this phone; nil when the
    /// session is not checked in (as far as this phone knows).
    private func checkedInText(_ session: Session) -> String? {
        if let local = checkedInLocal[session.id] {
            return local == Self.offlineCheckIn ? "Check-in saved offline — will sync when connected" : "Checked in at \(local)"
        }
        guard let raw = session.checkedInAt else { return nil }
        return "Checked in at \(Self.checkInTime(raw))"
    }

    /// The server's check-in time ("YYYY-MM-DD HH:MM:SS", server time) as this phone's clock
    /// shows it; the raw value when it can't be read.
    private static func checkInTime(_ raw: String) -> String {
        guard let date = APIDate.parseDateTimeCentral(raw) else { return raw }
        return date.formatted(date: .omitted, time: .shortened)
    }

    /// What the row says to VoiceOver, in reading order: who, when, whether it has ended,
    /// instructor, where (or remote), and whether completing logs hours.
    private func sessionSummary(_ session: Session, started: Bool) -> String {
        var parts = [session.client, formatDateTime(session.startAt)]
        if session.overdue == true { parts.append("Ended — awaiting an outcome") }
        if let checked = checkedInText(session) { parts.append(checked) }
        if let instructor = session.instructor, !instructor.isEmpty { parts.append("Instructor: \(instructor)") }
        if session.isRemote == true {
            parts.append(joinURL(session) != nil ? "Remote, with an online meeting link" : "Remote")
        } else if let location = session.location, !location.isEmpty {
            parts.append(location)
        }
        if session.trackId != nil { parts.append("Completing logs hours automatically") }
        if !started { parts.append("Can be marked completed once it has started.") }
        return parts.joined(separator: ". ")
    }

    /// The session's meeting link, when it is one the row offers to open.
    private func joinURL(_ session: Session) -> URL? {
        // https only, as the scheduling field promises: an http link would open unencrypted.
        guard session.isRemote == true, let u = session.meetingUrl, let url = URL(string: u),
              url.scheme?.lowercased() == "https" else { return nil }
        return url
    }

    /// Mark completed: sessions with a track bill hours — offer the client-signature step first
    /// (it can be completed without one, or cancelled). Without a track, completing closes the
    /// session for good, so it asks first, as the other outcomes do.
    private func markCompleted(_ session: Session) {
        if session.trackId != nil {
            completionKeys[session.id] = UUID().uuidString   // a new sheet, a new key
            signingSession = session
        }
        else { pendingOutcome = SessionOutcome(session: session, to: "Completed") }
    }

    /// Every session, or only this person's (4.0.0, remembered on the phone).
    private var shownSessions: [Session] {
        // A Completed session (a server that lists those with a note to write) is under Notes to write.
        let open = sessions.filter { $0.status != "Completed" }
        return mineOnly ? open.filter { $0.userId == nil || $0.userId == api.userId } : open
    }

    @ViewBuilder
    private func sessionRow(_ session: Session) -> some View {
        let instructor = (session.instructor ?? "").isEmpty ? nil : session.instructor
        let name = sessionName(session)
        // As on the website, Completed is offered once the session has started: the server
        // refuses it before then, after the client may already have signed for it. Checked
        // each minute, so it appears at the start time with the screen left open.
        TimelineView(.everyMinute) { context in
            let started = hasStarted(session, at: context.date)
            // Read-only while the list is the copy kept on this phone.
            let busy = completing.contains(session.id) || offlineSince != nil
            let checkIn = canCheckIn(session, at: context.date)
            VStack(alignment: .leading, spacing: 8) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(session.client).font(.body.weight(.semibold))
                    Text(formatDateTime(session.startAt))
                        .font(.callout)
                    // Said in words on the row too, for anyone moving row by row past the heading.
                    if session.overdue == true {
                        Text("Ended — awaiting an outcome").font(.caption.weight(.semibold)).foregroundStyle(Color.secondaryText)
                    }
                    if let checked = checkedInText(session) {
                        Label(checked, systemImage: "person.crop.circle.badge.checkmark")
                            .font(.callout.weight(.medium)).foregroundStyle(Color.brandTeal)
                    }
                    // Every instructor's sessions are listed: say whose this one is.
                    if let instructor {
                        Text("Instructor: \(instructor)").font(.callout).foregroundStyle(Color.secondaryText)
                    }
                    if session.isRemote == true {
                        Text("Remote").font(.caption2.weight(.semibold)).foregroundStyle(Color.brandTeal)
                            .padding(.horizontal, 6).padding(.vertical, 2)
                            .background(Color.brandTeal.opacity(0.15)).clipShape(Capsule())
                    } else if let location = session.location, !location.isEmpty, mapsURL(location) == nil {
                        Text(location).font(.callout).foregroundStyle(Color.secondaryText)
                    }
                    if session.trackId != nil {
                        Text("Completing logs hours automatically")
                            .font(.caption).foregroundStyle(Color.secondaryText)
                    }
                }
                // VoiceOver: the session is one stop, read in full; its buttons are the Actions
                // rotor's entries (swipe up or down, then double-tap), each asking first as on screen.
                // A double-tap on the row only says so (as the Tasks and Bookings rows do): it used to
                // be Mark completed, which for a tracked session opened the signature sheet, whose
                // Cancel locks the app — a stray double-tap locked the person out.
                .accessibilityElement(children: VoiceOverRows.children)
                .accessibilityLabel(sessionSummary(session, started: started))
                .accessibilityFocused($focusedSession, equals: session.id)
                .accessibilityAction { announceRowActions() }
                .accessibilityActions {
                    if checkIn, !checkingIn.contains(session.id) {
                        Button("Check in") { Task { await self.checkIn(session) } }
                    }
                    if !busy {
                        if started {
                            Button("Mark completed") { markCompleted(session) }
                        }
                        Button("Cancel session") { pendingOutcome = SessionOutcome(session: session, to: "Cancelled") }
                        if started {
                            Button("No-show") { pendingOutcome = SessionOutcome(session: session, to: "No Show") }
                        }
                        Button("Move session") { movingSession = session }
                        if session.inSeries { Button("Cancel this and later sessions in the series") { cancellingMore = (session, "cancel_series") } }
                        if session.groupUid != nil { Button("Cancel the whole group") { cancellingMore = (session, "cancel_group") } }
                        if let uid = session.groupUid, started, groupsOffered {
                            Button("Record attendance for the group") { recordingGroup = GroupRef(id: uid) }
                        }
                    }
                    if let url = joinURL(session) {
                        Button("Join online") { openURL(url) }
                    }
                    // The links on the row, which VoiceOver reads as one stop (4.0.0).
                    if session.isRemote != true, let location = session.location, let url = mapsURL(location) {
                        Button("Directions to \(location)") { openURL(url) }
                    }
                    if let cid = session.clientId, api.can("clients") {
                        Button("Open \(session.client)'s record") { openClientId = cid; showingClient = true }
                    }
                }
                // 4.35.0: the row's links, also after its one VoiceOver stop (reached by swiping
                // and on the rotor), each naming the session.
                if let url = joinURL(session) {
                    Link("Join online", destination: url).font(.callout)
                        .frame(minHeight: 44, alignment: .leading)   // the row's 44-point standard
                        .contentShape(Rectangle())
                        .accessibilityLabel("Join \(name) online")
                        .accessibilityInputLabels(["Join online", "Join \(name) online"])
                }
                if session.isRemote != true, let location = session.location, !location.isEmpty, let url = mapsURL(location) {
                    // Directions to the session's location (4.0.0).
                    Link(destination: url) { Text("\(location), directions").font(.callout) }
                        .frame(minHeight: 44, alignment: .leading)
                        .contentShape(Rectangle())
                        .accessibilityLabel("Directions to \(location), for the \(name)")
                        .accessibilityInputLabels(["Directions", "Directions to \(location)"])
                }
                if let cid = session.clientId, api.can("clients") {
                    NavigationLink(destination: ClientDetailView(clientId: cid)) { Text("Open \(session.client)'s record") }
                        .font(.callout)
                        .frame(minHeight: 44, alignment: .leading)
                        .contentShape(Rectangle())
                        .accessibilityLabel("Open \(session.client)'s record, from the \(name)")
                        .accessibilityInputLabels(["Open \(session.client)'s record"])
                }
                // 4.35.0: Check in and the outcomes are separate buttons after the row's one
                // VoiceOver stop, so they are reached by swiping as well as on the rotor. The row
                // itself still only says how to reach them when double-tapped (4.34.0).
                // Arriving: check in works offline too (kept on the phone with the notes and hours).
                if checkIn {
                    Button {
                        Task { await self.checkIn(session) }
                    } label: {
                        Label("Check in", systemImage: "person.crop.circle.badge.checkmark")
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                    .padding(.top, 4)
                    .onBrandLabel()     // dark text on the dark appearance's light-blue fill
                    .disabled(checkingIn.contains(session.id))
                    .accessibilityLabel("Check in to \(name)")
                    .accessibilityInputLabels(["Check in", "Check in to \(name)"])
                }
                if started {
                    Button {
                        markCompleted(session)
                    } label: {
                        Label("Mark completed", systemImage: "checkmark.circle")
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.large)        // 44-point targets (the regular size is about 34)
                    .padding(.top, 4)
                    .disabled(busy)
                    .accessibilityLabel("Mark \(name) completed")
                    .accessibilityInputLabels(["Mark completed", "Mark \(name) completed"])
                } else {
                    Text("Can be marked completed once it has started.")
                        .font(.caption).foregroundStyle(Color.secondaryText)
                        .padding(.top, 4)
                        .accessibilityHidden(true)   // said in the row's summary
                }
                // The other outcomes close the session without logging hours: each asks first.
                // Stacked at the accessibility text sizes, where side by side they broke mid-word.
                let outcomeLayout = typeSize.isAccessibilitySize
                    ? AnyLayout(VStackLayout(alignment: .leading, spacing: 8))
                    : AnyLayout(HStackLayout(spacing: 8))
                outcomeLayout {
                    Button {
                        pendingOutcome = SessionOutcome(session: session, to: "Cancelled")
                    } label: {
                        Label("Cancel session", systemImage: "xmark.circle")
                    }
                    .accessibilityLabel("Cancel \(name)")
                    .accessibilityInputLabels(["Cancel session", "Cancel \(name)"])
                    // As on the website, a no-show is recorded once the start has passed (4.34.0;
                    // the server refuses it before then).
                    if started {
                        Button {
                            pendingOutcome = SessionOutcome(session: session, to: "No Show")
                        } label: {
                            Label("No-show", systemImage: "person.crop.circle.badge.xmark")
                        }
                        .accessibilityLabel("Mark \(name) as a no-show")
                        .accessibilityInputLabels(["No-show", "Mark \(name) as a no-show"])
                    }
                }
                .buttonStyle(.bordered)
                .controlSize(.large)
                .padding(.top, 4)           // 8 points from Mark completed with the row's spacing
                .disabled(busy)
                // 4.35.0: outside the row's one VoiceOver stop, so each is reached by swiping
                // too (and kept on the rotor): nothing is rotor-only.
                let moreLayout = typeSize.isAccessibilitySize
                    ? AnyLayout(VStackLayout(alignment: .leading, spacing: 8))
                    : AnyLayout(HStackLayout(spacing: 8))
                // 4.35.0: the website's "Move or cancel more", as visible buttons (they were only
                // on the Actions rotor), each naming the session.
                moreLayout {
                    Button {
                        movingSession = session
                    } label: {
                        Label("Move session", systemImage: "calendar.badge.clock")
                    }
                    .accessibilityLabel("Move \(name)")
                    .accessibilityInputLabels(["Move session", "Move \(name)"])
                    if session.inSeries {
                        Button {
                            cancellingMore = (session, "cancel_series")
                        } label: {
                            Label("Cancel the series", systemImage: "calendar.badge.minus")
                        }
                        .accessibilityLabel("Cancel the series: \(name) and every later session in its weekly series")
                        .accessibilityInputLabels(["Cancel the series", "Cancel the series for \(session.client)"])
                    }
                    if session.groupUid != nil {
                        Button {
                            cancellingMore = (session, "cancel_group")
                        } label: {
                            Label("Cancel the whole group", systemImage: "person.3.sequence")
                        }
                        .accessibilityLabel("Cancel the whole group: the group \(name)")
                        .accessibilityInputLabels(["Cancel the whole group", "Cancel the whole group for \(session.client)"])
                    }
                }
                .buttonStyle(.bordered)
                .controlSize(.large)
                .disabled(busy)
                // 4.35.0: a group whose start has passed records who attended in one step.
                if let uid = session.groupUid, started, groupsOffered {
                    Button {
                        recordingGroup = GroupRef(id: uid)
                    } label: {
                        Label("Record attendance for the group", systemImage: "person.3.fill")
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.large)
                    .disabled(busy)
                    .accessibilityLabel("Record attendance for the group: \(name)")
                    .accessibilityInputLabels(["Record attendance for the group", "Record attendance for the group with \(session.client)"])
                }
            }
            .padding(.vertical, 4)
        }
    }

    /// check_in_session's reply (3.0.28). Tolerant: once the server says ok, a missing time
    /// must not turn a recorded check-in into an error the person would retry.
    private struct CheckInResult: Decodable {
        let checkedInAt: String?
        let message: String?
        private enum CodingKeys: String, CodingKey { case ok, checkedInAt, message }
        init(from decoder: Decoder) throws {
            let c = try decoder.container(keyedBy: CodingKeys.self)
            guard (try? c.decode(Bool.self, forKey: .ok)) == true else {
                throw DecodingError.dataCorruptedError(forKey: .ok, in: c, debugDescription: "not ok")
            }
            checkedInAt = try? c.decodeIfPresent(String.self, forKey: .checkedInAt)
            message = try? c.decodeIfPresent(String.self, forKey: .message)
        }
    }

    /// Check in (check_in_session): records that the session has begun. With no signal the
    /// check-in is kept on this phone and uploads with the offline notes and hours; one the
    /// server says is already checked in (409) is shown as checked in.
    private func checkIn(_ session: Session) async {
        guard !checkingIn.contains(session.id) else { return }
        checkingIn.insert(session.id)
        defer { checkingIn.remove(session.id) }
        confirmation = nil
        error = nil
        let body: [String: Any] = ["session_id": session.id]
        // When the button was pressed (4.27.0): sent with a check-in kept offline, so a later
        // upload records the arrival time, not the upload time.
        let pressedAt = OfflineSignatures.timestamp()
        do {
            let result: CheckInResult = try await api.call("check_in_session", body: body)
            let time = result.checkedInAt.map(Self.checkInTime) ?? Date().formatted(date: .omitted, time: .shortened)
            checkedInLocal[session.id] = time
            let message = "Checked in at \(time)."
            confirmation = message
            announce(message)
            await load(reportsFailure: false)
            writeTodaySnapshot()
        } catch APIError.network {
            do {
                var queued = body
                queued["checked_in_at"] = pressedAt
                try api.enqueue("check_in_session", body: queued,
                                label: "Session check-in, \(formatDateTime(session.startAt))")
                checkedInLocal[session.id] = Self.offlineCheckIn
                writeTodaySnapshot()
                let message = "No connection — check-in saved on this phone, will sync automatically."
                confirmation = message
                announce(message)
            } catch {
                showFormError("Could not save the check-in offline. \(error.localizedDescription)", in: &self.error)
            }
        } catch APIError.server(let message) where message.localizedCaseInsensitiveContains("already") {
            // Already checked in (from another phone, or an earlier try whose reply was lost).
            await load(reportsFailure: false)
            if sessions.first(where: { $0.id == session.id })?.checkedInAt == nil {
                checkedInLocal[session.id] = Date().formatted(date: .omitted, time: .shortened)
            }
            writeTodaySnapshot()
            confirmation = message
            announce(message)
        } catch {
            showFormError(error.localizedDescription, in: &self.error)
        }
    }

    /// The signed-in person's own sessions (4.28.0): reminders, the widget and Siri use only
    /// these, never every session the account can see. A session with no instructor sent is kept.
    private var ownSessions: [Session] {
        sessions.filter { $0.userId == nil || $0.userId == api.userId }
    }

    /// The day summary for the home-screen widget and the "Today's sessions" Siri shortcut:
    /// today's session times and check-ins, never a name (see TodaySnapshot).
    private func writeTodaySnapshot() {
        let now = Date()
        let entries: [TodaySnapshot.Entry] = ownSessions.compactMap { session in
            guard let start = APIDate.parseDateTimeCentral(session.startAt),
                  Calendar.current.isDate(start, inSameDayAs: now) else { return nil }
            return TodaySnapshot.Entry(start: start, end: APIDate.parseDateTimeCentral(session.endAt),
                                       checkedIn: checkedInText(session) != nil)
        }
        TodaySnapshot(day: TodaySnapshot.dayString(now), sessions: entries, savedAt: now).save()
        WidgetCenter.shared.reloadTimelines(ofKind: TodaySnapshot.widgetKind)
    }

    /// Cancelled or No Show (set_session_status): closes the session without logging hours.
    private func setStatus(_ session: Session, to status: String) async {
        guard !completing.contains(session.id) else { return }
        completing.insert(session.id)
        defer { completing.remove(session.id) }
        confirmation = nil
        // Cleared first so a repeat of the same failure is shown (and announced) again.
        error = nil
        let next = neighbour(of: session)
        do {
            let _: OKResponse = try await api.call("set_session_status", body: ["session_id": session.id, "to": status])
            let message = status == "Cancelled"
                ? "Session with \(session.client) cancelled."
                : "Session with \(session.client) marked as a no-show."
            confirmation = message
            await load()
            refocus(after: session, next: next, saying: message)
        } catch {
            let message = error.localizedDescription
            await load(reportsFailure: false)
            if loaded && self.error == nil && !sessions.contains(where: { $0.id == session.id }) {
                // The reply was lost but the session is no longer scheduled: say so, so a retry
                // ("Session not found or already closed") doesn't look like a second failure.
                showFormError(message + " The session is no longer listed as scheduled, so it may already have been closed. Check before trying again.", in: &self.error)
            } else {
                // Also keeps a failed refresh's reason, when there is one.
                showFormError([message, self.error].compactMap { $0 }.joined(separator: " "), in: &self.error)
            }
        }
    }

    /// `reportsFailure`: false when the caller says a failure itself, with its own (the refresh
    /// after a failed outcome).
    /// cancel_series or cancel_group (3.0.43).
    private func cancelMore(_ session: Session, action: String) async {
        error = nil; confirmation = nil
        do {
            let r: TaskSaveResult = try await api.call(action, body: ["session_id": session.id])
            confirmation = r.message ?? "Cancelled."
            await load()
            announce(confirmation ?? "")
        } catch { showFormError(error.localizedDescription, in: &self.error) }
    }

    private func load(reportsFailure: Bool = true) async {
        do {
            error = nil
            // With no signal, the last list the server sent is shown read-only instead.
            let (response, savedAt): (ScheduleListResponse, Date?) = try await api.callCached("schedule", cacheKey: "schedule")
            sessions = response.sessions
            upcomingTotal = response.upcomingTotal
            upcomingLimit = response.upcomingLimit
            loaded = true
            offlineSince = savedAt
            // Reminders follow the schedule as last loaded from the server (not the saved copy).
            await loadNotes()
            if savedAt == nil {
                LocalNotifications.shared.scheduleSessions(ownSessions)
                // Check-ins the server now reports no longer need this phone's own record.
                for session in sessions where session.checkedInAt != nil { checkedInLocal[session.id] = nil }
                writeTodaySnapshot()
            }
        } catch {
            if reportsFailure { showFormError(error.localizedDescription, in: &self.error) }
            else { self.error = error.localizedDescription }
        }
    }

    /// "Mark completed" on a session with no track (no signature step).
    private func completeFromList(_ session: Session) async {
        let next = neighbour(of: session)
        do {
            if let request = try await complete(session) {
                // 4.31.0: straight on to the session's case note.
                try? await Task.sleep(nanoseconds: 300_000_000)
                openNote(request)
            } else {
                refocus(after: session, next: next, saying: confirmation)
            }
        } catch {
            showFormError(error.localizedDescription, in: &self.error)
        }
    }

    /// Throws on failure, after refreshing the list: the session may have been completed even
    /// though the reply was lost, and the list then shows what is true now. Returns the session's
    /// case note to open (4.31.0), nil when this account cannot write notes; from the Complete
    /// session sheet it is opened once that sheet has closed.
    @discardableResult
    private func complete(_ session: Session, signature: String? = nil, signedName: String? = nil,
                          details: CompletionDetails? = nil,
                          outcome: CompletionOutcome = .completed) async throws -> SessionNoteRequest? {
        guard !completing.contains(session.id) else {
            throw APIError.server("This session is already being marked completed.")
        }
        completing.insert(session.id)
        defer { completing.remove(session.id) }
        confirmation = nil
        var refusedLogged: [LoggedHoursEntry] = []
        var refusedFields: [String: String] = [:]
        do {
            error = nil
            var body: [String: Any] = ["session_id": session.id]
            // 4.34.0: the outcome, as the website's Complete choices send it; when hours are
            // already logged that day the server answers with them (logged_hours) and the
            // Complete session sheet offers the website's two choices.
            body["outcome"] = outcome.value
            if let workLogId = outcome.workLogId { body["work_log_id"] = workLogId }
            let key = completionKeys[session.id] ?? UUID().uuidString
            completionKeys[session.id] = key
            body["idem_key"] = key
            if let signature { body["signature_b64"] = signature }
            if let signedName { body["signed_name"] = signedName }
            // What the Complete session step recorded (3.0.32 servers; older ones ignore it).
            // 4.31.0: no session note here any more; the full case note opens next.
            // 4.34.0: "hours already logged" records no new hours or miles (the server refuses
            // miles with it), so neither is sent then.
            if let details, outcome.value != CompletionOutcome.alreadyLoggedValue {
                body["hours"] = details.hours
                if details.miles > 0 { body["mileage"] = details.miles }
                // 4.35.0: the goal worked on and the service delivered, as the website's
                // "Hours, miles and goal" (sent only when the pickers were offered).
                if let goalId = details.goalId { body["goal_id"] = goalId }
                if let category = details.category { body["rsa_category"] = category }
            }
            let result: CompleteSessionReply = try await api.call("complete_session", body: body, refusal: { reply in
                refusedLogged = LoggedHoursEntry.list(reply["logged_hours"])
                refusedFields = (reply["errors"] as? [String: String]) ?? [:]
            })
            completionKeys[session.id] = nil
            let done: String = result.hoursLogged > 0
                ? String(format: "Session completed — %.2f hours logged for %@.", result.hoursLogged, session.client)
                : "Session completed."
            // Logged outside the authorization: said with it (the hours are logged either way).
            let warning: String = result.warning.map { " " + $0 } ?? ""
            confirmation = done + warning
            // The case note for this session (writing notes needs the clients permission).
            let request: SessionNoteRequest? = api.can("clients")
                ? SessionNoteTarget.afterCompletion(result, session: session).map {
                    SessionNoteRequest(target: $0, arrival: done + warning + " " + $0.contextLine + ".")
                }
                : nil
            if let c = confirmation, signingSession?.id == session.id {
                // From the signature sheet: the note opens (or the result is said) once it has
                // closed; from the list, completeFromList does either. Said now it would be cut off.
                if let request { noteAfterSheet = request } else { sheetResult = c }
            }
            await load()
            return request
        } catch {
            if !IdemKey.keeps(error) { completionKeys[session.id] = nil }
            if !refusedLogged.isEmpty, case APIError.server(let message) = error {
                // Nothing was recorded: the sheet asks which of the website's choices it is.
                throw LoggedHoursRefusal(message: message, entries: refusedLogged)
            }
            // 4.35.0: a goal or service no longer on the track: nothing was recorded, and the
            // sheet ties the refusal to its picker.
            if case APIError.server(let message) = error,
               let field = refusedFields["goal_id"] != nil ? "Goal worked on" : (refusedFields["rsa_category"] != nil ? "Service delivered" : nil) {
                throw FieldRefusal(message: message, field: field)
            }
            // Quietly: the failure is said with the completion's own message.
            await load(reportsFailure: false)
            if loaded && self.error == nil && !sessions.contains(where: { $0.id == session.id }) {
                // A retry answered "already closed" (the first try completed it, its reply lost):
                // when the session is under Notes to write, its case note opens as after a
                // completion instead of only an error.
                if case APIError.server = error, api.can("clients"),
                   let item = notesShown.first(where: { $0.sessionId == session.id }) {
                    completionKeys[session.id] = nil
                    let said = "This session was already completed."
                    confirmation = said
                    let request = SessionNoteRequest(target: item, arrival: said + " " + item.contextLine + ".")
                    if signingSession?.id == session.id { noteAfterSheet = request }
                    return request
                }
                // The reply was lost but the session is no longer scheduled: say so, so a retry
                // ("Session not found or already closed") doesn't look like a second failure.
                throw APIError.server(error.localizedDescription + " The session is no longer listed as scheduled, so it may already have been completed. Check before trying again.")
            }
            throw error
        }
    }
}

struct NewSessionSheet: View {
    @EnvironmentObject var api: API
    @Environment(\.dismiss) private var dismiss
    let onDone: (String) -> Void

    @State private var clients: [ClientRow] = []
    @State private var tracks: [TrackOption] = []
    @State private var staff: [StaffMember] = []
    @State private var myId: Int?
    @State private var selectedClient: Int?
    @State private var selectedTrack: Int?
    @State private var selectedStaff: Int?
    @State private var date = Date()
    @State private var duration = 1.5
    @State private var repeatWeeks = 1
    /// The authorization warnings the server returned for this booking ("Authorization review:"),
    /// shown with the approval switch. Cleared, with the approval, whenever the client, track,
    /// start, duration or series changes, so an approval only ever covers warnings seen for
    /// the booking as it is sent.
    @State private var authorizationWarning: String?
    @State private var authorizationAcknowledged = false
    /// The server's hash of the warnings shown (4.27.0), sent back with the approval so it
    /// covers exactly those warnings.
    @State private var authorizationHash: String?
    /// The refusal's authorization_warnings (4.28.0), shown instead of parsing its message.
    @State private var serverWarnings: [String]?
    /// Sent as idem_key (4.28.0), so a retry after a lost reply does not book the session twice.
    @State private var idem = IdemKey()
    @State private var location = ""
    @State private var notes = ""
    @State private var isRemote = false
    @State private var meetingUrl = ""
    @State private var busy = false
    @State private var error: String?
    /// The track list could not be loaded: without it a session can't be linked to a track,
    /// so completing it would log no hours. Said, with a retry, instead of hiding the picker.
    @State private var tracksError: String?
    @State private var askingDiscard = false

    /// Anything chosen or typed that closing the sheet would throw away.
    private var hasChanges: Bool {
        selectedClient != nil || selectedTrack != nil || repeatWeeks != 1 || isRemote
            || !location.isEmpty || !notes.isEmpty || !meetingUrl.isEmpty || authorizationAcknowledged
    }

    private var clientTracks: [TrackOption] {
        guard let clientId = selectedClient else { return [] }
        // Match by client id, not display name — two clients sharing a name would otherwise
        // cross tracks and a completed session would auto-log hours against the wrong client.
        let byId = tracks.filter { $0.clientId == clientId }
        if !byId.isEmpty { return byId }
        // Back-compat only: a server response that predates client_id (no track carries one).
        if tracks.allSatisfy({ $0.clientId == nil }),
           let clientName = clients.first(where: { $0.id == clientId })?.name {
            return tracks.filter { $0.client == clientName }
        }
        return byId
    }

    var body: some View {
        NavigationStack {
            ErrorFocusForm(inNavigationStack: true, error: error) {
                if let tracksError {
                    ErrorBanner(message: tracksError)
                    Button { Task { await loadTracks() } } label: {
                        Label("Try loading training tracks again", systemImage: "arrow.clockwise")
                    }
                }
                // Offered only after the server has named the warnings, next to them, and just
                // after the error banner (the next thing VoiceOver reaches from it).
                if let authorizationWarning {
                    Section("Authorization review") {
                        Text(authorizationWarning).font(.callout)
                        Toggle("I reviewed these authorization warnings and approve booking despite them", isOn: $authorizationAcknowledged)
                    }
                }
                Picker("Client (required)", selection: $selectedClient) {
                    Text("Choose…").tag(nil as Int?)
                    ForEach(clients) { client in
                        Text(client.name).tag(client.id as Int?)
                    }
                }
                .errorField("Client")
                if !clientTracks.isEmpty {
                    Picker("Training track", selection: $selectedTrack) {
                        Text("None").tag(nil as Int?)
                        ForEach(clientTracks) { track in
                            Text(track.title).tag(track.id as Int?)
                        }
                    }
                    Text("Link a track so completing the session logs hours automatically.")
                        .font(.caption).foregroundStyle(Color.secondaryText)
                }
                Picker("Instructor", selection: $selectedStaff) {
                    ForEach(staff) { member in
                        Text(member.name).tag(member.id as Int?)
                    }
                }
                .errorField("Instructor")
                DatePicker("Starts", selection: $date)
                    .errorField("Starts")
                Stepper(value: $duration, in: 0.25...12, step: 0.25) {
                    Text(String(format: "Duration: %.2f hours", duration))
                }
                .voiceOverAdjustable("Duration", value: hoursSpoken(duration), binding: $duration, in: 0.25...12, step: 0.25)
                Stepper(value: $repeatWeeks, in: 1...26) {
                    Text(repeatWeeks == 1 ? "One session" : "Repeats weekly ×\(repeatWeeks)")
                }
                .voiceOverAdjustable("Repeats", value: repeatWeeks == 1 ? "One session only" : "Weekly, \(repeatWeeks) sessions",
                                     binding: $repeatWeeks, in: 1...26, step: 1)
                Toggle("Remote session", isOn: $isRemote)
                // Each name (and the link's format) stays visible above its field once it holds text.
                if isRemote {
                    CaptionedField(label: "Meeting link (optional, starts with https://)", text: $meetingUrl, prompt: "https://…", keyboard: .URL, errorName: "Meeting link")
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                } else {
                    CaptionedField(label: "Location (optional)", text: $location)
                }
                CaptionedField(label: "Notes (optional)", text: $notes)
            }
            .navigationTitle("New session")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { if hasChanges { askingDiscard = true } else { dismiss() } }
                        .disabled(busy)
                }
                ToolbarItem(placement: .confirmationAction) {
                    // Not dimmed for a missing client: submit() says what is needed. The label
                    // says when it is working (a weekly series with invites takes a while).
                    Button(busy ? "Scheduling…" : "Schedule") { Task { await submit() } }
                        .disabled(busy)
                }
            }
            .discardChangesGuard(hasChanges: hasChanges, busy: busy, question: "Discard this new session?",
                                 asking: $askingDiscard) { dismiss() }
            .task { await loadPickers() }
            // Switching client must clear a track chosen for the previous client,
            // or a completed session would auto-log hours against the wrong client.
            .onChange(of: selectedClient) { _ in selectedTrack = nil; clearAuthorizationReview() }
            // The warnings were for the booking as it was: any change that can alter them
            // withdraws the approval (the server is asked again on the next Schedule).
            .onChange(of: selectedTrack) { _ in clearAuthorizationReview() }
            .onChange(of: date) { _ in clearAuthorizationReview() }
            .onChange(of: duration) { _ in clearAuthorizationReview() }
            .onChange(of: repeatWeeks) { _ in clearAuthorizationReview() }
        }
    }

    private func clearAuthorizationReview() {
        authorizationWarning = nil
        authorizationAcknowledged = false
        authorizationHash = nil
    }

    /// The server's refusal when a booking needs the authorization warnings approved
    /// (api.php schedule_session).
    private static let authorizationReviewPrefix = "Authorization review:"

    private func loadPickers() async {
        // client_choices is open to scheduling groups without the clients permission (such as
        // Front Desk); a failure is said, not swallowed — an empty picker gave no reason.
        var clientProblem: String?
        do {
            clients = try await api.clientPickerChoices(forSchedule: true)
        } catch {
            let problem = "Could not load the client list. \(error.localizedDescription)"
            clientProblem = problem
            showFormError(problem, in: &self.error)
        }
        await loadTracks()
        do {
            let staffResponse: StaffResponse = try await api.call("staff")
            staff = staffResponse.staff
            struct Me: Decodable { let id: Int; let name: String }
            let me: Me = try await api.call("me")
            myId = me.id
            selectedStaff = staff.first(where: { $0.id == me.id })?.id ?? staff.first?.id
        } catch {
            showFormError([clientProblem, error.localizedDescription].compactMap { $0 }.joined(separator: " "), in: &self.error)
        }
    }

    /// Tracks need the clients permission: schedule-only accounts (which can't link a track)
    /// don't ask. For everyone else a failure is said, not swallowed.
    private func loadTracks() async {
        guard api.can("clients") else { return }
        tracksError = nil
        do {
            let trackResponse: TracksResponse = try await api.call("tracks")
            tracks = trackResponse.tracks
        } catch {
            showFormError("Could not load training tracks, so a session scheduled now can't be linked to one and won't log hours automatically. \(error.localizedDescription)", in: &tracksError)
        }
    }

    /// A meeting link the server will keep: https (as the field's caption promises), with a
    /// host, no spaces, 500 characters at most. Anything else used to be dropped by the server
    /// while the app said "scheduled".
    private static func isMeetingLink(_ text: String) -> Bool {
        guard text.count <= 500, !text.contains(where: { $0.isWhitespace }),
              let url = URL(string: text), url.scheme?.lowercased() == "https",
              let host = url.host, !host.isEmpty else { return false }
        return true
    }

    private func submit() async {
        guard let clientId = selectedClient else {
            showFormError("Client: choose who the session is with.", in: &error)
            return
        }
        guard let staffId = selectedStaff else {
            showFormError("Instructor: choose who leads the session. If the list is empty, close this form and open it again to reload it.", in: &error)
            return
        }
        let link = meetingUrl.trimmingCharacters(in: .whitespacesAndNewlines)
        if isRemote && !link.isEmpty && !Self.isMeetingLink(link) {
            showFormError("Meeting link: enter the whole address, starting with https://, or leave it blank.", in: &error)
            return
        }
        busy = true; error = nil
        announce("Scheduling.")
        // The server stores and interprets session times in America/Chicago (see
        // formatDateTime on the read side), so the date and time are written in that zone —
        // otherwise a device in another timezone skews the stored appointment/billing time.
        do {
            // Tolerant: a retry after a false "failed" would schedule the sessions twice.
            struct Result: Decodable {
                let inviteSent: Bool
                let sessionsCreated: Int
                private enum CodingKeys: String, CodingKey { case ok, inviteSent, sessionsCreated }
                init(from decoder: Decoder) throws {
                    let c = try decoder.container(keyedBy: CodingKeys.self)
                    guard (try? c.decode(Bool.self, forKey: .ok)) == true else {
                        throw DecodingError.dataCorruptedError(forKey: .ok, in: c, debugDescription: "not ok")
                    }
                    inviteSent = (try? c.decode(Bool.self, forKey: .inviteSent)) ?? false
                    sessionsCreated = (try? c.decode(Int.self, forKey: .sessionsCreated)) ?? 1
                }
            }
            var request: [String: Any] = [
                "client_id": clientId,
                "track_id": selectedTrack ?? 0,
                "staff_id": staffId,
                "date": APIDate.dayCentral(date),
                "time": APIDate.timeCentral(date),
                "duration": duration,
                "repeat_weeks": repeatWeeks,
                "authorization_ack": authorizationAcknowledged,
                // Hidden while Remote is on: a location typed before switching is not sent.
                "location": isRemote ? "" : location,
                "notes": notes,
                "is_remote": isRemote ? 1 : 0,
                "meeting_url": isRemote ? link : "",
            ]
            if authorizationAcknowledged, let authorizationHash { request["authorization_ack_hash"] = authorizationHash }
            // 4.28.0: a retry after a lost reply is recognised, so the session is not booked twice.
            request["idem_key"] = idem.key(for: request)
            var refusedHash: String?
            var refusedWarnings: [String]?
            var refusedDuplicate = false
            var refusedFields: [String: String] = [:]
            let result: Result
            do {
                result = try await api.call("schedule_session", body: request,
                                            refusal: {
                                                refusedHash = $0["authorization_hash"] as? String
                                                refusedWarnings = $0["authorization_warnings"] as? [String]
                                                refusedDuplicate = ($0["duplicate"] as? Bool) == true
                                                refusedFields = ($0["errors"] as? [String: String]) ?? [:]
                                            })
            } catch {
                authorizationHash = refusedHash
                serverWarnings = refusedWarnings
                idem.failed(error)
                // 4.34.0: the session is already on the schedule (the server refused a second
                // copy): said as information, not an error, since nothing is wrong.
                if refusedDuplicate, case APIError.server(let message) = error {
                    onDone(message)
                    dismiss()
                    return
                }
                // Some weeks of a series are already booked (errors.date), or the client is on
                // the waitlist or closed (errors.client_id): tied to the field to change.
                if case APIError.server = error {
                    if let dateError = refusedFields["date"] {
                        showFormError(dateError, in: &self.error, field: "Starts"); busy = false; return
                    }
                    if let clientError = refusedFields["client_id"] {
                        showFormError(clientError, in: &self.error, field: "Client"); busy = false; return
                    }
                }
                throw error
            }
            idem.answered()
            let base = result.sessionsCreated > 1 ? "Series of \(result.sessionsCreated) sessions scheduled." : "Session scheduled."
            let msg = base + (result.inviteSent ? " Calendar invite emailed." : "")
            // Said by the schedule once this sheet has closed (closing it would cut it off).
            onDone(msg)
            dismiss()
        } catch APIError.server(let message) where message.hasPrefix(Self.authorizationReviewPrefix) {
            // The warnings are shown with the approval switch, which is offered only now.
            // 4.28.0: the warnings themselves, from the refusal's authorization_warnings, never the
            // server's instruction sentences parsed out of its message.
            var warnings = message.dropFirst(Self.authorizationReviewPrefix.count).trimmingCharacters(in: .whitespaces)
            if let list = serverWarnings, !list.isEmpty {
                warnings = list.joined(separator: " ")
            } else {
                for sentence in [" These warnings are not the ones you approved", " Review the track and explicitly approve"] {
                    if let instruction = warnings.range(of: sentence, options: .backwards) {
                        warnings = String(warnings[..<instruction.lowerBound])
                    }
                }
            }
            authorizationWarning = warnings
            authorizationAcknowledged = false
            showFormError(message + " To book it anyway, turn on the approval just below this message, then tap Schedule again.", in: &self.error)
            busy = false
        } catch APIError.network {
            // The request may have reached the server: the session (or the whole series) may be
            // booked and the invite sent, and scheduling it again would book it twice.
            let who = clients.first(where: { $0.id == clientId })?.name ?? "this client"
            showFormError("The connection dropped before the server answered, so it isn't known whether this was scheduled. Check the Schedule for \(who) on \(date.formatted(date: .abbreviated, time: .shortened)) before scheduling it again.", in: &self.error)
            busy = false
        } catch {
            showFormError(error.localizedDescription, in: &self.error)
            busy = false
        }
    }
}

/// What the Complete session step records with the outcome.
struct CompletionDetails {
    let hours: Double
    let miles: Double
    /// 4.35.0: the goal worked on (nil: none) and the service delivered (nil: not offered, so
    /// the server uses the track's default).
    var goalId: Int? = nil
    var category: String? = nil
}

/// A refusal about one field of a sheet (4.35.0), so the sheet can tie it to that field.
struct FieldRefusal: LocalizedError {
    let message: String
    let field: String
    var errorDescription: String? { message }
}

/// complete_session's `outcome` (4.34.0), as the website's Complete choices: completed, or —
/// when hours are already logged for the track that day — completed with those hours (one
/// entry, `work_log_id`) or with new hours logged as well.
struct CompletionOutcome {
    let value: String
    var workLogId: Int?
    static let alreadyLoggedValue = "completed_logged"
    static let completed = CompletionOutcome(value: "completed")
    static let separate = CompletionOutcome(value: "completed_separate")
    static func alreadyLogged(_ id: Int) -> CompletionOutcome { CompletionOutcome(value: alreadyLoggedValue, workLogId: id) }
}

/// One of the hours already logged that day, from a refusal's `logged_hours`.
struct LoggedHoursEntry: Identifiable, Equatable {
    let id: Int
    let hours: Double
    let description: String

    static func list(_ raw: Any?) -> [LoggedHoursEntry] {
        guard let rows = raw as? [[String: Any]] else { return [] }
        return rows.compactMap { row in
            let id = (row["id"] as? Int) ?? Int(row["id"] as? String ?? "")
            guard let id, id > 0 else { return nil }
            let hours = (row["hours"] as? Double) ?? Double(row["hours"] as? String ?? "") ?? 0
            return LoggedHoursEntry(id: id, hours: hours, description: (row["description"] as? String) ?? "")
        }
    }

    /// "1.5 hours: Training session…", the entry as the website lists it.
    var summary: String {
        let h = String(format: "%g", hours)
        return description.isEmpty ? "\(h) hours" : "\(h) hours: \(description)"
    }
}

/// complete_session refused because hours are already logged that day (its 422 with logged_hours).
struct LoggedHoursRefusal: LocalizedError {
    let message: String
    let entries: [LoggedHoursEntry]
    var errorDescription: String? { message }
}

/// Completing a session on a track: the hours (the scheduled length unless changed) and miles,
/// then the client's signature or none. Staff fill this in; only the signature step is handed
/// to the client. 4.31.0: no session note here; the full case note opens once it is completed.
struct CompleteSessionSheet: View {
    let session: Session
    let onDone: (_ details: CompletionDetails, _ signatureB64: String?, _ signedName: String?,
                 _ outcome: CompletionOutcome) async throws -> Void
    @EnvironmentObject var api: API
    @Environment(\.dismiss) private var dismiss
    @State private var hoursText = ""
    @State private var milesText = ""
    /// 4.35.0: the track's open goals and its services (visit categories), as the website's
    /// "Hours, miles and goal". Empty when they could not be loaded (offline): the pickers are
    /// then absent and nothing is sent, so the server uses the website's defaults.
    @State private var openGoals: [Goal] = []
    @State private var categories: [String] = []
    @State private var goalId: Int?
    @State private var category = ""
    @State private var busy = false
    @State private var error: String?
    @State private var signing: SigningStep?
    @State private var finished = false
    /// Hours already logged that day (4.34.0): the completion waits for the website's choice,
    /// keeping what was entered and the client's signature and signed name.
    @State private var loggedChoice: LoggedHoursChoice?
    /// The refusal's message, said once the signature sheet (and its app lock) has gone.
    @State private var choiceMessage: String?

    /// The scheduled length in quarter hours, as the server would log it.
    private var scheduledHours: Double {
        let f = DateFormatter(); f.locale = Locale(identifier: "en_US_POSIX"); f.dateFormat = "yyyy-MM-dd HH:mm:ss"
        guard let a = f.date(from: session.startAt), let b = f.date(from: session.endAt), b > a else { return 0 }
        return (b.timeIntervalSince(a) / 3600 * 4).rounded() / 4
    }

    private static func number(_ raw: String) -> Double? {
        let t = raw.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: ",", with: ".")
        guard t.range(of: "^[0-9]{0,4}(\\.[0-9]{1,2})?$", options: .regularExpression) != nil, !t.isEmpty else { return nil }
        return Double(t)
    }

    /// The entry checked as the server checks it, or the message saying what to fix.
    private func checked() -> CompletionDetails? {
        guard let hours = Self.number(hoursText), hours <= 24 else {
            showFormError("Hours: enter a number from 0 to 24, such as 1.5.", in: &error); return nil
        }
        let milesRaw = milesText.trimmingCharacters(in: .whitespacesAndNewlines)
        let miles = milesRaw.isEmpty ? 0 : (Self.number(milesRaw) ?? -1)
        guard miles >= 0, miles <= 1000 else {
            showFormError("Miles: enter the miles driven, from 0 to 1000, like 12.5.", in: &error); return nil
        }
        guard miles == 0 || hours > 0 else {
            showFormError("Hours: miles are logged with hours, so enter the hours worked, or clear the miles.", in: &error); return nil
        }
        return CompletionDetails(hours: hours, miles: miles,
                                 goalId: openGoals.isEmpty ? nil : goalId,
                                 category: categories.count > 1 && !category.isEmpty ? category : nil)
    }

    /// The pickers are offered as the website offers them: the goal when the track has open
    /// goals ("None" first), the service when it has more than one.
    static func visitChoicesShown(openGoals: Int, categories: Int) -> (goal: Bool, service: Bool) {
        (openGoals >= 1, categories > 1)
    }

    /// The track's open goals (goals?track_id=) and visit categories (tracks), as Log hours reads
    /// them. A failure leaves both pickers out.
    private func loadVisitChoices() async {
        guard let trackId = session.trackId, api.can("clients") else { return }
        if let r: GoalsResponse = try? await api.call("goals", query: ["track_id": String(trackId)]) {
            openGoals = r.goals.filter { $0.status != "Achieved" }
        }
        if let r: TracksResponse = try? await api.call("tracks"),
           let list = r.tracks.first(where: { $0.id == trackId })?.visitCategories {
            categories = list
            if category.isEmpty || !list.contains(category) { category = list.first ?? "" }
        }
    }

    private func completeWithoutSignature() async {
        guard let details = checked() else { return }
        busy = true; error = nil
        do {
            try await onDone(details, nil, nil, .completed)
            dismiss()
        } catch let refusal as LoggedHoursRefusal {
            loggedChoice = LoggedHoursChoice(details: details, signature: nil, signedName: nil, entries: refusal.entries)
            showFormError(Self.choiceText(refusal.message), in: &self.error)
        } catch let refusal as FieldRefusal {
            showFormError(refusal.message, in: &self.error, field: refusal.field)
        } catch {
            showFormError(error.localizedDescription, in: &self.error)
        }
        busy = false
    }

    /// The server's sentence and what to do next, in the error summary.
    private static func choiceText(_ message: String) -> String {
        message + " Choose below: Completed, hours already logged, or Completed — log hours as well."
    }

    /// One of the website's choices, with what was signed before and the Hours and Miles as
    /// they are now (checked again: they may have been changed since the refusal).
    private func choose(_ outcome: CompletionOutcome) async {
        guard let choice = loggedChoice else { return }
        let details: CompletionDetails
        if outcome.value == CompletionOutcome.alreadyLoggedValue {
            // Nothing new is logged: the hours and miles typed are not sent.
            details = choice.details
        } else {
            guard let now = checked() else { return }
            details = now
        }
        busy = true; error = nil
        do {
            try await onDone(details, choice.signature, choice.signedName, outcome)
            loggedChoice = nil
            dismiss()
        } catch let refusal as LoggedHoursRefusal {
            loggedChoice = LoggedHoursChoice(details: details, signature: choice.signature,
                                             signedName: choice.signedName, entries: refusal.entries)
            showFormError(Self.choiceText(refusal.message), in: &self.error)
        } catch let refusal as FieldRefusal {
            showFormError(refusal.message, in: &self.error, field: refusal.field)
        } catch {
            showFormError(error.localizedDescription, in: &self.error)
        }
        busy = false
    }

    var body: some View {
        NavigationStack {
            ErrorFocusForm(inNavigationStack: true, error: error) {
                if let choice = loggedChoice {
                    Section("Hours already logged that day") {
                        ForEach(Array(choice.entries.enumerated()), id: \.element.id) { index, entry in
                            Button { Task { await choose(.alreadyLogged(entry.id)) } } label: {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Completed, hours already logged" + (choice.entries.count > 1 ? " as entry \(index + 1)" : ""))
                                    Text(entry.summary).font(.caption).foregroundStyle(Color.secondaryText)
                                }
                                .accessibilityElement(children: .combine)
                            }
                            .disabled(busy)
                        }
                        Button("Completed — log hours as well") { Task { await choose(.separate) } }
                            .disabled(busy)
                    }
                }
                CaptionedField(label: "Hours worked", text: $hoursText, keyboard: .decimalPad, errorName: "Hours")
                CaptionedField(label: "Miles driven (optional)", text: $milesText, keyboard: .decimalPad, errorName: "Miles")
                let shown = Self.visitChoicesShown(openGoals: openGoals.count, categories: categories.count)
                if shown.goal {
                    Picker("Goal worked on", selection: $goalId) {
                        Text("None").tag(nil as Int?)
                        ForEach(openGoals) { g in Text(g.specificGoal).lineLimit(2).tag(g.id as Int?) }
                    }
                    .errorField("Goal worked on")
                }
                if shown.service {
                    Picker("Service delivered", selection: $category) {
                        ForEach(categories, id: \.self) { Text($0).tag($0) }
                    }
                    .errorField("Service delivered")
                }
                Button("Get the client's signature") {
                    if let details = checked() { error = nil; loggedChoice = nil; signing = SigningStep(details: details) }
                }
                .disabled(busy)
                Button {
                    Task { await completeWithoutSignature() }
                } label: {
                    HStack(spacing: 8) {
                        Text("Complete without signature")
                        if busy { ProgressView().accessibilityHidden(true) }
                    }
                }
                .disabled(busy)
                .accessibilityValue(busy ? "Saving" : "")
            }
            .navigationTitle("Complete session")
            // Nothing typed is lost to a swipe down: Cancel is the way out.
            .interactiveDismissDisabled(busy || !milesText.isEmpty)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }.disabled(busy)
                }
            }
            .onAppear {
                if hoursText.isEmpty { hoursText = String(format: "%g", scheduledHours) }
            }
            .task { await loadVisitChoices() }
            .sheet(item: $signing, onDismiss: {
                if finished { dismiss() }
                else if let message = choiceMessage {
                    // Back with the device owner (the app was locked as the pad closed): the choice is theirs.
                    choiceMessage = nil
                    showFormError(Self.choiceText(message), in: &error)
                }
            }) { step in
                SignatureSheet(clientName: session.client) { sig, name in
                    do {
                        try await onDone(step.details, sig, name, .completed)
                        finished = true
                    } catch let refusal as LoggedHoursRefusal {
                        // The signature and name are kept; the pad closes (locking the app) and
                        // the staff member chooses here, not the client.
                        loggedChoice = LoggedHoursChoice(details: step.details, signature: sig, signedName: name, entries: refusal.entries)
                        choiceMessage = refusal.message
                    }
                }
            }
        }
    }
}

/// The signature step's sheet item (CompletionDetails itself has no identity).
private struct SigningStep: Identifiable {
    let id = UUID()
    let details: CompletionDetails
}

/// A completion waiting for the website's choice (4.34.0), with what was entered and signed.
private struct LoggedHoursChoice {
    let details: CompletionDetails
    let signature: String?
    let signedName: String?
    let entries: [LoggedHoursEntry]
}

/// Move a session to a new time (move_session, 3.0.43). When the server has warnings (the
/// instructor already booked, outside the authorization), they are shown and the move is
/// sent again only once the person chooses Move anyway.
struct MoveSessionSheet: View {
    @EnvironmentObject var api: API
    @Environment(\.dismiss) private var dismiss
    let session: Session
    let onMoved: (String) -> Void
    @State private var start: Date
    @State private var hours: Double
    @State private var warnings: [String] = []
    /// The hash of the warnings shown (4.28.0), sent as confirm_hash with Move anyway; cleared
    /// when the time or length changes (the server shows the warnings for the new one first).
    @State private var warningsHash: String?
    @State private var busy = false
    @State private var error: String?

    init(session: Session, onMoved: @escaping (String) -> Void) {
        self.session = session
        self.onMoved = onMoved
        let f = DateFormatter(); f.dateFormat = "yyyy-MM-dd HH:mm:ss"; f.locale = Locale(identifier: "en_US_POSIX")
        let s = f.date(from: session.startAt) ?? Date()
        let e = f.date(from: session.endAt) ?? s.addingTimeInterval(3600)
        _start = State(initialValue: s)
        _hours = State(initialValue: max(0.25, (e.timeIntervalSince(s) / 3600 * 4).rounded() / 4))
    }

    var body: some View {
        NavigationStack {
            ErrorFocusForm(inNavigationStack: true, error: error) {
                Section("Session with \(session.client)") {
                    DatePicker("New start", selection: $start)
                        .errorField("New start")
                    Stepper("Length: \(hours.formatted()) hours", value: $hours, in: 0.25...12, step: 0.25)
                        // One adjustable stop, as the New session form's Duration (4.30.0).
                        .voiceOverAdjustable("Length", value: hoursSpoken(hours), binding: $hours, in: 0.25...12, step: 0.25)
                }
                if !warnings.isEmpty {
                    Section("Check before moving") {
                        ForEach(warnings, id: \.self) { Text($0) }
                        Button(busy ? "Moving…" : "Move anyway") { Task { await move(confirm: true) } }.disabled(busy)
                    }
                }
            }
            .navigationTitle("Move session")
            .onChange(of: start) { _ in warnings = []; warningsHash = nil }
            .onChange(of: hours) { _ in warnings = []; warningsHash = nil }
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button(busy ? "Moving…" : "Move") { Task { await move(confirm: false) } }.disabled(busy) }
            }
        }
    }

    private func move(confirm: Bool) async {
        busy = true; error = nil
        defer { busy = false }
        let f = DateFormatter(); f.dateFormat = "yyyy-MM-dd HH:mm"; f.locale = Locale(identifier: "en_US_POSIX")
        do {
            var body: [String: Any] = ["session_id": session.id, "start_at": f.string(from: start),
                                       "duration": hours, "confirm": confirm]
            if confirm, let warningsHash { body["confirm_hash"] = warningsHash }
            var refusedFields: [String: String] = [:]
            let r: MoveSessionResult
            do {
                r = try await api.call("move_session", body: body, refusal: { refusedFields = ($0["errors"] as? [String: String]) ?? [:] })
            } catch APIError.server(let message) {
                // A refused time is about the date field (4.34.0): said there, with the field.
                let aboutDate = refusedFields["start_at"] != nil || refusedFields["date"] != nil
                showFormError(message, in: &self.error, field: aboutDate ? "New start" : nil)
                return
            }
            if r.moved == true {
                onMoved(r.message ?? "Session moved.")
                dismiss()
            } else {
                warnings = r.warnings ?? []
                warningsHash = r.warningsHash
                announce("Not moved yet. " + warnings.joined(separator: " ") + " Choose Move anyway if the time is right.")
            }
        } catch { showFormError(error.localizedDescription, in: &self.error) }
    }
}

// MARK: - Group sessions (4.35.0): booking and recording attendance, as the website's Schedule

/// A group being recorded (the sheet's item).
struct GroupRef: Identifiable { let id: String }

/// A client's active track in group_choices, newest first.
struct GroupChoiceTrack: Decodable, Identifiable, Hashable {
    let id: Int
    let title: String
    private enum CodingKeys: String, CodingKey { case id, title }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        guard let id = SessionNoteTarget.int(c, .id) else {
            throw DecodingError.dataCorruptedError(forKey: .id, in: c, debugDescription: "no id")
        }
        self.id = id
        title = (try? c.decode(String.self, forKey: .title)) ?? "Training track"
    }
}

/// A bookable client in group_choices, with their active tracks.
struct GroupChoiceClient: Decodable, Identifiable {
    let id: Int
    let name: String
    let tracks: [GroupChoiceTrack]
    private enum CodingKeys: String, CodingKey { case id, name, tracks }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        guard let id = SessionNoteTarget.int(c, .id) else {
            throw DecodingError.dataCorruptedError(forKey: .id, in: c, debugDescription: "no id")
        }
        self.id = id
        name = (try? c.decode(String.self, forKey: .name)) ?? ""
        tracks = LenientList.decode(GroupChoiceTrack.self, from: c, forKey: .tracks)
    }
}

/// group_choices (4.35.0): the website's bookable clients in scope, the instructors, and who is
/// chosen first.
struct GroupChoicesResponse: Decodable {
    let clients: [GroupChoiceClient]
    let staff: [StaffMember]
    let defaultStaffId: Int?
    private enum CodingKeys: String, CodingKey { case clients, staff, defaultStaffId }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        clients = LenientList.decode(GroupChoiceClient.self, from: c, forKey: .clients)
        staff = LenientList.decode(StaffMember.self, from: c, forKey: .staff)
        defaultStaffId = SessionNoteTarget.int(c, .defaultStaffId)
    }
}

/// schedule_group's reply. Tolerant: once the server says ok, a missing count must not turn a
/// booked group into an error the person would retry.
struct GroupBookReply: Decodable {
    let sessionsCreated: Int
    let noTrack: [String]
    let inviteSent: Bool
    let message: String?
    private enum CodingKeys: String, CodingKey { case ok, sessionsCreated, noTrack, inviteSent, message }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        guard (try? c.decode(Bool.self, forKey: .ok)) == true else {
            throw DecodingError.dataCorruptedError(forKey: .ok, in: c, debugDescription: "not ok")
        }
        sessionsCreated = SessionNoteTarget.int(c, .sessionsCreated) ?? 0
        noTrack = (try? c.decodeIfPresent([String].self, forKey: .noTrack)) ?? []
        inviteSent = SessionNoteTarget.flag(c, .inviteSent) ?? false
        message = try? c.decodeIfPresent(String.self, forKey: .message)
    }
}

/// One client's session in a group (group_session).
struct GroupSessionMember: Decodable, Identifiable {
    let sessionId: Int
    let clientId: Int
    let clientName: String
    let trackId: Int?
    let trackTitle: String?
    var id: Int { sessionId }
    private enum CodingKeys: String, CodingKey { case sessionId, clientId, clientName, trackId, trackTitle }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        guard let sid = SessionNoteTarget.int(c, .sessionId) else {
            throw DecodingError.dataCorruptedError(forKey: .sessionId, in: c, debugDescription: "no session")
        }
        sessionId = sid
        clientId = SessionNoteTarget.int(c, .clientId) ?? 0
        clientName = (try? c.decode(String.self, forKey: .clientName)) ?? ""
        let track = SessionNoteTarget.int(c, .trackId)
        trackId = (track ?? 0) > 0 ? track : nil
        let title = (try? c.decodeIfPresent(String.self, forKey: .trackTitle)) ?? nil
        trackTitle = (title?.isEmpty ?? true) ? nil : title
    }
}

/// group_session (4.35.0): the group card's members, and whether it can be recorded yet.
struct GroupSessionResponse: Decodable {
    let startAt: String
    let started: Bool
    let instructor: String?
    let canRecord: Bool
    /// The website's prefill for the hours ("" when no member has a track).
    let defaultHours: String
    let members: [GroupSessionMember]
    private enum CodingKeys: String, CodingKey { case startAt, started, instructor, canRecord, defaultHours, members }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        startAt = (try? c.decode(String.self, forKey: .startAt)) ?? ""
        started = SessionNoteTarget.flag(c, .started) ?? false
        instructor = try? c.decodeIfPresent(String.self, forKey: .instructor)
        members = LenientList.decode(GroupSessionMember.self, from: c, forKey: .members)
        canRecord = SessionNoteTarget.flag(c, .canRecord) ?? (started && members.count >= 2)
        if let text = try? c.decode(String.self, forKey: .defaultHours) { defaultHours = text }
        else if let number = try? c.decode(Double.self, forKey: .defaultHours) { defaultHours = String(format: "%g", number) }
        else { defaultHours = "" }
    }
}

/// complete_group's reply (4.35.0): the website's message and each case note to write.
struct GroupCompleteReply: Decodable {
    let completed: Int
    let message: String?
    let notesToWrite: [SessionNoteTarget]
    private enum CodingKeys: String, CodingKey { case ok, completed, message, notesToWrite }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        guard (try? c.decode(Bool.self, forKey: .ok)) == true else {
            throw DecodingError.dataCorruptedError(forKey: .ok, in: c, debugDescription: "not ok")
        }
        completed = SessionNoteTarget.int(c, .completed) ?? 0
        message = try? c.decodeIfPresent(String.self, forKey: .message)
        notesToWrite = LenientList.decode(SessionNoteTarget.self, from: c, forKey: .notesToWrite)
    }
}

/// Schedule a group session (schedule_group, 4.35.0), with the website's fields in its order:
/// the clients (two or more, each with their training track), the instructor, date, start
/// time, duration, location, notes, remote and meeting link. Warnings are approved as on the
/// single booking form, by the hash of the warnings shown.
struct GroupSessionSheet: View {
    @EnvironmentObject var api: API
    @Environment(\.dismiss) private var dismiss
    let onDone: (String) -> Void

    @State private var choices: GroupChoicesResponse?
    @State private var loadError: String?
    @State private var picked: Set<Int> = []
    /// The track chosen for a client with more than one (the newest is preselected).
    @State private var trackPicks: [Int: Int] = [:]
    @State private var staffId: Int?
    @State private var day = Date()
    @State private var time = Calendar.current.date(bySettingHour: 10, minute: 0, second: 0, of: Date()) ?? Date()
    @State private var durationText = "1.5"
    @State private var location = ""
    @State private var notes = ""
    @State private var isRemote = false
    @State private var meetingUrl = ""
    /// The warnings the server named (authorization_warnings), with the approval and its hash.
    @State private var warnings: [String] = []
    @State private var warningsHash: String?
    @State private var approved = false
    @State private var idem = IdemKey()
    @State private var busy = false
    @State private var error: String?
    @State private var askingDiscard = false

    private var clients: [GroupChoiceClient] { choices?.clients ?? [] }

    /// The date and start time the form opened with (today, 10:00 as on the website).
    @State private var openedDay = Date()
    @State private var openedTime = Calendar.current.date(bySettingHour: 10, minute: 0, second: 0, of: Date()) ?? Date()

    private var hasChanges: Bool {
        !picked.isEmpty || !location.isEmpty || !notes.isEmpty || isRemote || !meetingUrl.isEmpty || durationText != "1.5"
            || !Calendar.current.isDate(day, inSameDayAs: openedDay)
            || Calendar.current.dateComponents([.hour, .minute], from: time) != Calendar.current.dateComponents([.hour, .minute], from: openedTime)
    }

    /// "Jane Doe — Screen reader training", or that no hours will be logged for her; a client
    /// with more than one track is named alone (the picker under them says which).
    static func clientLabel(_ name: String, tracks: [String]) -> String {
        if tracks.isEmpty { return "\(name) — no active training track, so no hours will be logged" }
        if tracks.count == 1 { return "\(name) — \(tracks[0])" }
        return name
    }

    /// The fields an error key is about, in the form's order (the server's `errors` keys).
    private func fieldName(_ key: String) -> String? {
        if key.hasPrefix("track_"), let cid = Int(key.dropFirst(6)), let c = clients.first(where: { $0.id == cid }) {
            return "Training track for \(c.name)"
        }
        return ["clients": "Clients", "staff_id": "Instructor", "date": "Date", "time": "Start time", "duration": "Duration",
                "location": "Location", "notes": "Notes", "meeting_url": "Meeting link"][key]
    }

    static let warningsBanner = "This group booking needs your approval. Check the warnings below, then turn on the approval and tap Schedule group session again."

    private static let fieldOrder = ["clients", "staff_id", "date", "time", "duration", "location", "notes", "meeting_url"]

    var body: some View {
        NavigationStack {
            ErrorFocusForm(inNavigationStack: true, error: error) {
                if let loadError {
                    ErrorBanner(message: loadError)
                    Button { Task { await loadChoices() } } label: {
                        Label("Try loading the clients again", systemImage: "arrow.clockwise")
                    }
                }
                // Offered only once the server has named the warnings, just after the error.
                if !warnings.isEmpty {
                    Section("Warnings to review") {
                        ForEach(warnings, id: \.self) { Text($0).font(.callout) }
                        Toggle("I reviewed these warnings and approve this group booking despite them", isOn: $approved)
                    }
                }
                Section("Clients (required: choose two or more)") {
                    if choices == nil && loadError == nil {
                        ProgressView("Loading clients…")
                    } else if choices != nil && clients.isEmpty {
                        Text("No clients can be booked: each needs a status that is not Waitlist or Closed.")
                            .foregroundStyle(Color.secondaryText)
                    }
                    ForEach(Array(clients.enumerated()), id: \.element.id) { index, client in
                        let label = Self.clientLabel(client.name, tracks: client.tracks.map(\.title))
                        let on = Binding(get: { picked.contains(client.id) },
                                         set: { if $0 { picked.insert(client.id) } else { picked.remove(client.id) } })
                        if index == 0 {
                            Toggle(label, isOn: on).errorField("Clients")
                        } else {
                            Toggle(label, isOn: on)
                        }
                        if picked.contains(client.id) && client.tracks.count > 1 {
                            Picker("Training track for \(client.name) (their hours log here; the newest track is preselected)", selection: Binding(
                                get: { trackPicks[client.id] ?? client.tracks[0].id },
                                set: { trackPicks[client.id] = $0 })) {
                                ForEach(client.tracks) { Text($0.title).tag($0.id) }
                            }
                            .errorField("Training track for \(client.name)")
                        }
                    }
                }
                // The website's group form labels (schedule.php).
                Picker("Group session instructor", selection: $staffId) {
                    ForEach(choices?.staff ?? []) { Text($0.name).tag($0.id as Int?) }
                }
                .errorField("Instructor")
                DatePicker("Group session date (required)", selection: $day, displayedComponents: .date)
                    .errorField("Date")
                DatePicker("Group session start time (required)", selection: $time, displayedComponents: .hourAndMinute)
                    .errorField("Start time")
                CaptionedField(label: "Group session duration (hours) (required)", text: $durationText, keyboard: .decimalPad, errorName: "Duration")
                CaptionedField(label: "Group session location", text: $location, errorName: "Location")
                CaptionedField(label: "Group session notes", text: $notes, errorName: "Notes")
                Toggle("Group session is remote / telepractice", isOn: $isRemote)
                CaptionedField(label: "Meeting link (https://…; tick Remote above to use it)", text: $meetingUrl,
                               prompt: "https://…", keyboard: .URL, errorName: "Meeting link")
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
            }
            .navigationTitle("Schedule a group session")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { if hasChanges { askingDiscard = true } else { dismiss() } }
                        .disabled(busy)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(busy ? "Scheduling…" : "Schedule group session") { Task { await submit() } }
                        .disabled(busy || choices == nil)
                }
            }
            .discardChangesGuard(hasChanges: hasChanges, busy: busy, question: "Discard this group session?",
                                 asking: $askingDiscard) { dismiss() }
            .task { await loadChoices() }
            // The warnings were for the booking as it was: a change that can alter them withdraws
            // the approval (the server is asked again on the next Schedule group).
            .onChange(of: picked) { _ in clearWarnings() }
            .onChange(of: trackPicks) { _ in clearWarnings() }
            .onChange(of: staffId) { _ in clearWarnings() }
            .onChange(of: day) { _ in clearWarnings() }
            .onChange(of: time) { _ in clearWarnings() }
            .onChange(of: durationText) { _ in clearWarnings() }
        }
    }

    private func clearWarnings() {
        warnings = []
        warningsHash = nil
        approved = false
    }

    private func loadChoices() async {
        loadError = nil
        do {
            let r: GroupChoicesResponse = try await api.call("group_choices")
            choices = r
            if staffId == nil { staffId = r.defaultStaffId ?? r.staff.first(where: { $0.id == api.userId })?.id ?? r.staff.first?.id }
        } catch {
            showFormError("Could not load the clients who can be booked. \(error.localizedDescription)", in: &loadError)
        }
    }

    /// The day from Date and the hour and minute from Start time, as one moment.
    private var start: Date {
        let cal = Calendar.current
        let d = cal.dateComponents([.year, .month, .day], from: day)
        let t = cal.dateComponents([.hour, .minute], from: time)
        return cal.date(from: DateComponents(year: d.year, month: d.month, day: d.day, hour: t.hour, minute: t.minute)) ?? day
    }

    /// The request as schedule_group takes it: the clients in the list's order, each one's
    /// track when they have more than one, and the time in the server's zone.
    static func groupBody(clientIds: [Int], tracks: [Int: Int], staffId: Int, start: Date, duration: Double,
                          location: String, notes: String, isRemote: Bool, meetingUrl: String) -> [String: Any] {
        [
            "client_ids": clientIds,
            "tracks": Dictionary(uniqueKeysWithValues: tracks.map { (String($0.key), $0.value) }),
            "staff_id": staffId,
            "date": APIDate.dayCentral(start),
            "time": APIDate.timeCentral(start),
            "duration": duration,
            "location": location,
            "notes": notes,
            "is_remote": isRemote ? 1 : 0,
            "meeting_url": meetingUrl,
        ]
    }

    private func submit() async {
        let chosen = clients.filter { picked.contains($0.id) }
        guard chosen.count >= 2 else {
            showFormError("Clients: choose at least two clients.", in: &error, field: "Clients"); return
        }
        guard let staffId else {
            showFormError("Instructor: choose who leads the group session.", in: &error, field: "Instructor"); return
        }
        let durationRaw = durationText.trimmingCharacters(in: .whitespaces).replacingOccurrences(of: ",", with: ".")
        guard let duration = Double(durationRaw), duration >= 0.25, duration <= 12 else {
            showFormError("Duration: enter a duration between 0.25 and 12 hours.", in: &error, field: "Duration"); return
        }
        let link = meetingUrl.trimmingCharacters(in: .whitespacesAndNewlines)
        if !link.isEmpty && !isRemote {
            showFormError("Meeting link: a meeting link was entered but \"Group session is remote / telepractice\" is off. Turn it on, or clear the link.", in: &error, field: "Meeting link"); return
        }
        var tracks: [Int: Int] = [:]
        for c in chosen where c.tracks.count > 1 { tracks[c.id] = trackPicks[c.id] ?? c.tracks[0].id }
        var body = Self.groupBody(clientIds: chosen.map(\.id), tracks: tracks, staffId: staffId, start: start, duration: duration,
                                  location: location.trimmingCharacters(in: .whitespaces), notes: notes.trimmingCharacters(in: .whitespaces),
                                  isRemote: isRemote, meetingUrl: link)
        if approved, let warningsHash { body["authorization_ack_hash"] = warningsHash }
        // A retry after a lost reply is recognised, so the group is not booked twice.
        body["idem_key"] = idem.key(for: body)
        busy = true; error = nil
        announce("Scheduling the group session.")
        defer { busy = false }
        var refusedFields: [String: String] = [:]
        var refusedWarnings: [String] = []
        var refusedHash: String?
        var refusedDuplicate = false
        do {
            let r: GroupBookReply = try await api.call("schedule_group", body: body, refusal: { reply in
                refusedFields = (reply["errors"] as? [String: String]) ?? [:]
                refusedWarnings = (reply["authorization_warnings"] as? [String]) ?? []
                refusedHash = reply["authorization_hash"] as? String
                refusedDuplicate = (reply["duplicate"] as? Bool) == true
            })
            idem.answered()
            let message = r.message ?? "Group session scheduled for \(r.sessionsCreated) clients."
            onDone(message)
            dismiss()
        } catch {
            idem.failed(error)
            if case APIError.network = error {
                showFormError("The connection dropped before the server answered, so it isn't known whether the group was scheduled. Check the Schedule for \(start.formatted(date: .abbreviated, time: .shortened)) before scheduling it again.", in: &self.error)
                return
            }
            let message = error.localizedDescription
            // The same group is already on the schedule: said as information, nothing is wrong.
            if refusedDuplicate {
                onDone(message)
                dismiss()
                return
            }
            if !refusedWarnings.isEmpty {
                warnings = refusedWarnings
                warningsHash = refusedHash
                approved = false
                // The warnings are listed once, in the section below the banner.
                showFormError(Self.warningsBanner, in: &self.error)
                return
            }
            let keys = refusedFields.keys.sorted { a, b in
                (Self.fieldOrder.firstIndex(of: a) ?? 50) < (Self.fieldOrder.firstIndex(of: b) ?? 50)
            }
            if let key = keys.first, let text = refusedFields[key] {
                showFormError(text, in: &self.error, field: fieldName(key))
                return
            }
            showFormError(message, in: &self.error)
        }
    }
}

/// Record who attended a group session and complete it (complete_group, 4.35.0), as the
/// website's group card: everyone ticked is Completed with hours logged to their track, anyone
/// not ticked is recorded as No Show with no hours logged.
struct GroupAttendanceSheet: View {
    @EnvironmentObject var api: API
    @Environment(\.dismiss) private var dismiss
    let groupUid: String
    /// The server's message and the case notes to write, first one first.
    let onDone: (_ message: String, _ notes: [SessionNoteTarget]) -> Void

    @State private var group: GroupSessionResponse?
    @State private var loadError: String?
    @State private var attended: Set<Int> = []
    @State private var hoursText = ""
    @State private var confirming = false
    @State private var idem = IdemKey()
    @State private var busy = false
    @State private var error: String?

    /// The website's confirmation sentence (schedule.php's group card).
    static func groupConfirmText(attended: Int, total: Int, billable: Int, hours: String) -> String {
        let hv = hours.trimmingCharacters(in: .whitespaces)
        let none = !hv.isEmpty && !((Double(hv.replacingOccurrences(of: ",", with: ".")) ?? 0) > 0)
        return "Record attendance for this group session? \(attended) of \(total) clients attended and will be marked Completed"
            + (none ? ", with no hours logged. "
                    : ", and \(billable) of them will have \(hv.isEmpty ? "hours" : hv + " hours") logged to their training track and billed. ")
            + "\(total - attended) will be recorded as No Show, with no hours logged."
    }

    /// notes_to_write carries no track or time: each note is linked to its member's track and
    /// the group's session day, so the case note opens on that track (4.35.0).
    static func notesWithMembers(_ notes: [SessionNoteTarget], group: GroupSessionResponse) -> [SessionNoteTarget] {
        notes.map { n in
            let m = group.members.first { $0.sessionId == n.sessionId }
            return SessionNoteTarget(sessionId: n.sessionId, clientId: n.clientId > 0 ? n.clientId : (m?.clientId ?? 0),
                                     clientName: n.clientName.isEmpty ? (m?.clientName ?? "") : n.clientName,
                                     trackId: n.trackId ?? m?.trackId, sessionDate: n.sessionDate.isEmpty ? String(group.startAt.prefix(10)) : n.sessionDate,
                                     startAt: n.startAt ?? group.startAt, noteSubject: n.noteSubject)
        }
    }

    private var confirmText: String {
        let members = group?.members ?? []
        let present = members.filter { attended.contains($0.sessionId) }
        return Self.groupConfirmText(attended: present.count, total: members.count,
                                     billable: present.filter { $0.trackId != nil }.count, hours: hoursText)
    }

    var body: some View {
        NavigationStack {
            ErrorFocusForm(inNavigationStack: true, error: error) {
                if let loadError {
                    ErrorBanner(message: loadError)
                    Button { Task { await load() } } label: {
                        Label("Try loading the group again", systemImage: "arrow.clockwise")
                    }
                } else if group == nil {
                    ProgressView("Loading the group…")
                }
                if let group {
                    Section("Group session of \(formatDateTime(group.startAt))") {
                        if let instructor = group.instructor, !instructor.isEmpty {
                            LabeledContent("Instructor", value: instructor)
                        }
                        if !group.canRecord {
                            Text(group.started ? "This group has fewer than two clients still scheduled. Record each one from the schedule."
                                               : "It can be completed once it has started, with who attended.")
                                .foregroundStyle(Color.secondaryText)
                        }
                    }
                    if group.canRecord {
                        Section("Who attended? (untick anyone who did not come: they are recorded as No Show, with no hours logged)") {
                            ForEach(group.members) { m in
                                Toggle("\(m.clientName) attended (" + (m.trackId != nil ? "hours logged to \(m.trackTitle ?? "their training track")" : "no training track, so no hours are logged") + ")",
                                       isOn: Binding(get: { attended.contains(m.sessionId) },
                                                     set: { if $0 { attended.insert(m.sessionId) } else { attended.remove(m.sessionId) } }))
                            }
                        }
                        CaptionedField(label: "Hours for each client who attended (blank: each client's own scheduled length)",
                                       text: $hoursText, keyboard: .decimalPad, errorName: "Hours")
                        Button {
                            if checkedHours() != nil { confirming = true }
                        } label: {
                            HStack(spacing: 8) {
                                Text("Record attendance and complete")
                                if busy { ProgressView().accessibilityHidden(true) }
                            }
                        }
                        .disabled(busy)
                        .accessibilityValue(busy ? "Saving" : "")
                    }
                }
            }
            .navigationTitle("Record attendance")
            .navigationBarTitleDisplayMode(.inline)
            .interactiveDismissDisabled(busy)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }.disabled(busy)
                }
            }
            .confirmationDialog(confirmText, isPresented: $confirming, titleVisibility: .visible) {
                Button("Record attendance") { Task { await submit() } }
                Button("Not yet", role: .cancel) {}
            }
            .task { await load() }
        }
    }

    /// "" (each client's own scheduled length) or 0 to 24 with up to two decimals; nil after
    /// saying what to fix.
    private func checkedHours() -> String? {
        let t = hoursText.trimmingCharacters(in: .whitespaces).replacingOccurrences(of: ",", with: ".")
        if t.isEmpty { return "" }
        // As the server reads it (session_group_hours_input: any number from 0 to 24, ".5" and
        // "3.125" too, rounded to two decimals there).
        guard t.range(of: "^([0-9]+\\.?[0-9]*|\\.[0-9]+)$", options: .regularExpression) != nil, let h = Double(t), h <= 24 else {
            showFormError("Hours: enter the hours for each client who attended as a number from 0 to 24, such as 1.5, or leave it blank.", in: &error, field: "Hours")
            return nil
        }
        return t
    }

    private func load() async {
        loadError = nil
        do {
            let r: GroupSessionResponse = try await api.call("group_session", query: ["group_uid": groupUid])
            group = r
            attended = Set(r.members.map(\.sessionId))   // all ticked, as on the website
            if hoursText.isEmpty { hoursText = r.defaultHours }
        } catch {
            showFormError(error.localizedDescription, in: &loadError)
        }
    }

    private func submit() async {
        guard let group, let hours = checkedHours() else { return }
        var body: [String: Any] = [
            "group_uid": groupUid,
            "listed": group.members.map(\.sessionId),
            "attended": group.members.map(\.sessionId).filter { attended.contains($0) },
            "hours": hours,
        ]
        body["idem_key"] = idem.key(for: body)
        busy = true; error = nil
        announce("Recording attendance.")
        defer { busy = false }
        var refusedFields: [String: String] = [:]
        do {
            let r: GroupCompleteReply = try await api.call("complete_group", body: body, refusal: { reply in
                refusedFields = (reply["errors"] as? [String: String]) ?? [:]
            })
            idem.answered()
            onDone(r.message ?? "Attendance recorded: \(r.completed) completed.", Self.notesWithMembers(r.notesToWrite, group: group))
            dismiss()
        } catch {
            idem.failed(error)
            if let text = refusedFields["hours"] {
                showFormError(text, in: &self.error, field: "Hours")
            } else {
                showFormError(IdemKey.message(for: error, what: "the attendance"), in: &self.error)
            }
        }
    }
}
