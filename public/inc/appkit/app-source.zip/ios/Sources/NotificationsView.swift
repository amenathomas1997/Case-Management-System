import SwiftUI

/// One in-app alert (the website's Alerts page).
struct AlertItem: Decodable, Identifiable {
    let id: Int
    let message: String
    /// The website page the alert points to, relative to the site (client.php?id=4…); nil when none.
    let link: String?
    let createdAt: String
    let unread: Bool
    private enum CodingKeys: String, CodingKey { case id, message, link, createdAt, unread }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        id = try c.decode(Int.self, forKey: .id)
        message = (try? c.decode(String.self, forKey: .message)) ?? ""
        link = try? c.decodeIfPresent(String.self, forKey: .link)
        createdAt = (try? c.decode(String.self, forKey: .createdAt)) ?? ""
        unread = (try? c.decode(Bool.self, forKey: .unread)) ?? false
    }
}

struct AlertsResponse: Decodable { let notifications: [AlertItem]; let unread: Int }
struct AlertCount: Decodable { let unread: Int }
struct AlertsMarked: Decodable {
    let marked: Int
    let unread: Int
    let message: String?
    /// The batch just marked read (4.36.0), to mark it unread again within 15 minutes; nil from
    /// an older server or when nothing was marked.
    let undo: AlertsUndo?
    private enum CodingKeys: String, CodingKey { case marked, unread, message, undo }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        marked = (try? c.decode(Int.self, forKey: .marked)) ?? 0
        unread = (try? c.decode(Int.self, forKey: .unread)) ?? 0
        message = (try? c.decodeIfPresent(String.self, forKey: .message)) ?? nil
        undo = (try? c.decodeIfPresent(AlertsUndo.self, forKey: .undo)) ?? nil
    }
}

/// mark_notifications_read's undo: the batch's ids ("1,2,3"), its read stamp, and how many.
struct AlertsUndo: Decodable {
    let ids: String
    let stamp: String
    let count: Int
}

struct AlertsUnmarked: Decodable { let restored: Int?; let unread: Int?; let message: String }

/// The undo offered after marking alerts read, kept for the website's 15 minutes.
struct AlertsUndoOffer {
    let undo: AlertsUndo
    let madeAt: Date
    /// The website's 15 minutes, after which the server refuses the undo.
    static let lifetime: TimeInterval = 15 * 60
    var stillOffered: Bool { Date().timeIntervalSince(madeAt) < AlertsUndoOffer.lifetime }
    var secondsLeft: TimeInterval { max(0, AlertsUndoOffer.lifetime - Date().timeIntervalSince(madeAt)) }
    var label: String { "Undo: mark the \(undo.count) alert\(undo.count == 1 ? "" : "s") just marked read as unread again" }
}

/// Where an alert's link leads in the app: a matching screen, or the website page.
enum AlertDestination: Hashable {
    case client(Int), referral(Int), tasks(String), portalRequests, incidents, messages, counselors
    case thread(Int, String), followups, schedule, referrals
    /// 4.38.0 (T6): Incoming authorizations, or one email's review.
    case authorizations, authorization(Int)

    /// The app screen for a website link, when the account may open it here.
    @MainActor static func from(_ link: String, api: API) -> AlertDestination? {
        guard let parts = URLComponents(string: link) else { return nil }
        let page = (parts.path as NSString).lastPathComponent
        let query = Dictionary((parts.queryItems ?? []).map { ($0.name, $0.value ?? "") }, uniquingKeysWith: { a, _ in a })
        switch page {
        case "client.php": if api.can("clients"), let id = Int(query["id"] ?? "") { return .client(id) }
        case "referrals.php":
            if api.can("referrals") {
                if let id = Int(query["view"] ?? ""), id > 0 { return .referral(id) }
                return .referrals     // 4.36.0: the list, as Android
            }
        case "tasks.php": return .tasks(query["due"] ?? "any")
        case "portal_requests.php": if api.can("clients") { return .portalRequests }
        case "incidents.php": if api.can("clients") { return .incidents }
        case "messages.php":
            // 4.36.0: a link to one conversation opens it, on its channel (as Android does).
            if api.can("clients") {
                if let id = Int(query["client"] ?? ""), id > 0 { return .thread(id, query["channel"] == "counselor" ? "counselor" : "client") }
                return .messages
            }
        case "counselors.php": if api.can("admin") { return .counselors }
        case "followups.php": if api.can("clients") { return .followups }
        case "schedule.php": if api.can("schedule") { return .schedule }
        case "authorizations.php":
            // 4.38.0: "A new authorization email (…) is waiting on Incoming authorizations."
            if api.can("clients") && api.serverAtLeast(4, 38) {
                if let id = Int(query["id"] ?? ""), id > 0 { return .authorization(id) }
                return .authorizations
            }
        default: break
        }
        return nil
    }

    @ViewBuilder var screen: some View {
        switch self {
        case .client(let id): ClientDetailView(clientId: id)
        case .referral(let id): ReferralDetailView(referralId: id)
        case .tasks(let due): TasksView(due: due)
        case .portalRequests: PortalRequestsView()
        case .incidents: IncidentsView()
        case .messages: MessagesView()
        case .counselors: CounselorsView()
        case .thread(let id, let channel): MessageThreadView(clientId: id, clientName: "", startChannel: channel)
        case .followups: FollowupsView()
        case .schedule: ScheduleView()
        case .referrals: ReferralsView()
        case .authorizations: AuthorizationsView()
        case .authorization(let id): AuthorizationReviewView(emailId: id)
        }
    }
}

/// The website's Alerts page: things that happened while the person was away, unread ones
/// first. Opening one goes to the matching screen in the app (or the website page in the
/// in-app browser) and marks it read.
struct NotificationsView: View {
    @EnvironmentObject var api: API
    /// Told the unread count after every load and change (the dashboard's badge).
    var onUnreadChange: (Int) -> Void = { _ in }
    @State private var items: [AlertItem] = []
    @State private var unread = 0
    @State private var loaded = false
    @State private var error: String?
    @State private var busy = false
    @State private var destination: AlertDestination?
    @State private var webPage: WebPage?
    @AccessibilityFocusState private var errorFocused: Bool
    /// Counts failed Mark as read taps: each scrolls to the error banner and focuses it.
    @State private var revealError = 0
    /// The last batch marked read, which can be marked unread again for 15 minutes (4.36.0).
    @State private var undoOffer: AlertsUndoOffer?
    @Environment(\.scenePhase) private var scenePhase

    private var shownUnread: [AlertItem] { items.filter(\.unread) }

    var body: some View {
        ScrollViewReader { proxy in
        List {
            if let error {
                ErrorBanner(message: error).listRowSeparator(.hidden).accessibilityFocused($errorFocused)
                    .id("alertsError")
            }
            if loaded {
                if let undoOffer, undoOffer.stillOffered {
                    Button { Task { await undoMarkRead(undoOffer) } } label: {
                        Label(undoOffer.label, systemImage: "arrow.uturn.backward")
                            .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
                    }
                    .disabled(busy)
                }
                Section {
                    if !shownUnread.isEmpty {
                        Button { Task { await markRead(shownUnread.map(\.id)) } } label: {
                            Label(unread > shownUnread.count ? "Mark these \(shownUnread.count) as read" : "Mark all as read",
                                  systemImage: "checkmark.circle")
                                .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
                        }
                        .disabled(busy)
                    }
                    if unread > shownUnread.count {
                        Text("Showing the newest \(shownUnread.count) of \(unread) unread alerts. Mark these as read to list the older ones.")
                            .font(.callout)
                    }
                } footer: {
                    Text("Things that happened while you were away. Emails still go out as usual; this is the in-app copy.")
                        .foregroundStyle(Color.secondaryText)
                }
                if items.isEmpty { Text("Nothing yet.").foregroundStyle(Color.secondaryText) }
                Section {
                    ForEach(items) { item in row(item) }
                } header: {
                    Text(unread > 0 ? "Alerts (\(unread) new)" : "Alerts").font(.headline).foregroundStyle(.primary).textCase(nil)
                        .accessibilityAddTraits(.isHeader)
                }
            } else if error == nil {
                ProgressView("Loading alerts…")
            }
        }
        // A failed Mark as read from further down: the banner is scrolled into view (a List never
        // draws an off-screen row, which then can't take focus), then VoiceOver is put on it.
        .onChange(of: revealError) { _ in
            DispatchQueue.main.async {
                withAnimation(UIAccessibility.isReduceMotionEnabled ? nil : .default) { proxy.scrollTo("alertsError", anchor: .top) }
            }
            Task { @MainActor in
                try? await Task.sleep(nanoseconds: 400_000_000)
                errorFocused = true
            }
        }
        }
        .navigationTitle("Alerts")
        .navigationDestination(isPresented: Binding(get: { destination != nil }, set: { if !$0 { destination = nil } })) {
            if let destination { destination.screen }
        }
        .sheet(item: $webPage) { page in
            InAppWebView(url: page.url) { webPage = nil }.ignoresSafeArea()
        }
        .refreshable { await load() }
        .task { await load() }
        // The undo button goes at 15 minutes: a timer while the screen is open, and a check on
        // coming back to the app (a suspended timer may not have fired).
        .task(id: undoOffer?.madeAt) {
            guard let offer = undoOffer else { return }
            try? await Task.sleep(nanoseconds: UInt64(offer.secondsLeft * 1_000_000_000))
            guard !Task.isCancelled, undoOffer?.madeAt == offer.madeAt else { return }
            undoOffer = nil
        }
        .onChange(of: scenePhase) { phase in
            if phase == .active, let offer = undoOffer, !offer.stillOffered { undoOffer = nil }
        }
    }

    @ViewBuilder private func row(_ item: AlertItem) -> some View {
        let target = item.link.flatMap { AlertDestination.from($0, api: api) }
        let webURL = target == nil ? item.link.flatMap(workflowURL) : nil
        let content = VStack(alignment: .leading, spacing: 3) {
            HStack(alignment: .firstTextBaseline) {
                Text(item.message).font(item.unread ? .body.weight(.semibold) : .body)
                Spacer()
                if item.unread {
                    Text("New").font(.caption2.weight(.semibold)).foregroundStyle(.white)
                        .padding(.horizontal, 6).padding(.vertical, 2)
                        .background(Color.brandFill).clipShape(Capsule())
                }
            }
            Text(formatDateTime(item.createdAt)).font(.caption).foregroundStyle(Color.secondaryText)
        }
        .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
        .contentShape(Rectangle())
        Group {
            if target != nil || webURL != nil {
                Button { open(item, target: target, webURL: webURL) } label: { content }
                    .buttonStyle(.plain)
            } else {
                // An alert that opens nothing is a plain row (4.30.0), not a disabled button:
                // that dimmed its text below the app's contrast and VoiceOver called it "dimmed".
                content
            }
        }
        // One stop: new or read, the message and when; opening and marking read are its actions.
        .accessibilityElement(children: VoiceOverRows.children)
        .accessibilityLabel("\(item.unread ? "New. " : "")\(item.message). \(formatDateTime(item.createdAt))")
        .accessibilityHint(target != nil ? "Opens the matching screen." : (webURL != nil ? "Opens the website page in the app." : ""))
        .accessibilityAddTraits(target != nil || webURL != nil ? .isButton : [])
        .accessibilityActions {
            if target != nil || webURL != nil { Button("Open") { open(item, target: target, webURL: webURL) } }
            if item.unread { Button("Mark as read") { Task { await markRead([item.id]) } } }
        }
    }

    private func open(_ item: AlertItem, target: AlertDestination?, webURL: URL?) {
        if item.unread { Task { await markRead([item.id], quietly: true) } }
        if let target { destination = target }
        else if let webURL { webPage = WebPage(url: webURL) }
    }

    private func markRead(_ ids: [Int], quietly: Bool = false) async {
        guard !ids.isEmpty else { return }
        busy = true
        defer { busy = false }
        do {
            let r: AlertsMarked = try await api.call("mark_notifications_read", body: ["ids": ids.map(String.init).joined(separator: ",")])
            // Opening one alert marks it read without offering an undo: only Mark as read does.
            if !quietly, let undo = r.undo, undo.count > 0 { undoOffer = AlertsUndoOffer(undo: undo, madeAt: Date()) }
            await load()
            if !quietly { announce(r.message ?? "Marked as read.") }
        } catch {
            if !quietly {
                showFormError(error.localizedDescription, in: &self.error)
                // VoiceOver is put on the banner, which reads it: not announced as well (4.30.0).
                claimFormErrorFocus(error.localizedDescription)
                revealError += 1
            }
        }
    }

    /// Marks the batch just marked read as unread again (mark_notifications_unread); the server
    /// restores only that batch, only within 15 minutes.
    private func undoMarkRead(_ offer: AlertsUndoOffer) async {
        busy = true
        defer { busy = false }
        do {
            let r: AlertsUnmarked = try await api.call("mark_notifications_unread", method: "POST",
                                                       body: ["ids": offer.undo.ids, "stamp": offer.undo.stamp])
            undoOffer = nil
            await load()
            announce(r.message)
        } catch {
            undoOffer = nil
            showFormError(error.localizedDescription, in: &self.error)
            claimFormErrorFocus(error.localizedDescription)
            revealError += 1
        }
    }

    private func load() async {
        do {
            error = nil
            let r: AlertsResponse = try await api.call("notifications")
            items = r.notifications
            unread = r.unread
            loaded = true
            onUnreadChange(r.unread)
        } catch { showFormError(error.localizedDescription, in: &self.error) }
    }
}
