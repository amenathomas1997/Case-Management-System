import SwiftUI

/// My agreements (4.15.0): the staff agreements to read and sign by typing your name, and copies
/// of those signed (api_more.php agreements, sign_agreement, agreement_copy).
struct AgreementsView: View {
    @EnvironmentObject var api: API
    @State private var items: [[String: Any]] = []
    @State private var loaded = false
    @State private var error: String?

    var body: some View {
        List {
            if let error { ErrorBanner(message: error).listRowSeparator(.hidden) }
            if !loaded && error == nil { ProgressView("Loading your agreements…") }
            if loaded {
                let needed = items.filter { ($0["state"] as? String) == "needed" }.count
                Text(items.isEmpty ? "There are no agreements for you to sign."
                     : needed > 0 ? "\(needed) of \(items.count) need your signature." : "Every agreement is signed and current.")
            }
            ForEach(Array(items.enumerated()), id: \.offset) { _, a in
                let id = a["id"] as? Int ?? 0
                let needs = (a["state"] as? String) == "needed"
                NavigationLink {
                    AgreementDetailView(id: id, onSigned: { Task { await load() } })
                } label: {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(a["title"] as? String ?? "Agreement").font(.body.weight(.semibold))
                        Text(needs ? "Needs your signature: " + (a["why"] as? String ?? "").lowercased() : (a["why"] as? String ?? ""))
                            .font(.subheadline).foregroundStyle(Color.secondaryText)
                    }
                    .accessibilityElement(children: .combine)
                }
            }
        }
        .navigationTitle("My agreements")
        .task { await load() }
        .refreshable { await load() }
    }

    private func load() async {
        do {
            let r = try await api.callDict("agreements")
            items = r["agreements"] as? [[String: Any]] ?? []
            loaded = true; error = nil
        } catch { self.error = error.localizedDescription }
    }
}

struct AgreementDetailView: View {
    @EnvironmentObject var api: API
    @Environment(\.dismiss) private var dismiss
    let id: Int
    let onSigned: () -> Void
    @State private var agreement: [String: Any]?
    @State private var agree = false
    @State private var name = ""
    @State private var busy = false
    @State private var error: String?
    @AccessibilityFocusState private var bannerFocused: Bool

    var body: some View {
        ScrollViewReader { proxy in
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                if let error {
                    ErrorBanner(message: error)
                        .id("agreementError")
                        .accessibilityFocused($bannerFocused)
                }
                if let a = agreement {
                    Text(a["title"] as? String ?? "Agreement").font(.title2.weight(.semibold)).accessibilityAddTraits(.isHeader)
                    Text((a["why"] as? String ?? "") + ".")
                    KBBlocksView(text: a["body"] as? String ?? "")
                    // 4.36.0: the signed copy whenever there is a signature, as the website's
                    // "Signed copy" link: an agreement due for renewal shows it and Sign.
                    if let sid = a["signature_id"] as? Int {
                        NavigationLink("Read your signed copy") { AgreementCopyView(id: sid) }
                    }
                    if (a["state"] as? String) != "signed" {
                        Text("Sign").font(.headline).accessibilityAddTraits(.isHeader).padding(.top, 8)
                        // Both are needed to sign: said in their labels (4.30.0), and a Sign tap
                        // with either missing says which, on that field, rather than a dimmed button.
                        Toggle("I have read this agreement and agree to it (required)", isOn: $agree)
                            .errorField("Agree")
                        CaptionedField(label: "Type your full name to sign (required), as it is on your account: \(api.userName)", text: $name,
                                       errorName: "Name")
                            .textContentType(.name)
                        Button {
                            Task { await sign(a) }
                        } label: {
                            Text(busy ? "Signing…" : "Sign the agreement").frame(maxWidth: .infinity, minHeight: 44)
                        }
                        .buttonStyle(.borderedProminent)
                        .onBrandLabel()
                        .disabled(busy)
                    }
                } else if error == nil {
                    ProgressView("Loading the agreement…")
                }
            }.padding()
        }
        .modifier(ErrorFocusing(error: error, proxy: proxy, bannerID: "agreementError", bannerFocused: $bannerFocused))
        }
        .navigationTitle("Agreement")
        .navigationBarTitleDisplayMode(.inline)
        .task { await load() }
    }

    private func load() async {
        do {
            let r = try await api.callDict("agreements")
            agreement = (r["agreements"] as? [[String: Any]] ?? []).first { ($0["id"] as? Int) == id }
            if agreement == nil { error = "That agreement is no longer asked for." }
        } catch { self.error = error.localizedDescription }
    }

    /// sign_agreement's refusals of the typed name (staff_agreement_sign), when no error key is sent.
    static let nameRefusals = ["Type your full name to sign.", "Type your full name as it is on your account",
                               "The name typed does not match the name on your account"]

    private func sign(_ a: [String: Any]) async {
        guard agree else { showFormError("Agree: turn on that you have read the agreement and agree to it.", in: &error); return }
        guard !name.trimmingCharacters(in: .whitespaces).isEmpty else {
            showFormError("Name: type your full name to sign, as it is on your account.", in: &error); return
        }
        busy = true; error = nil
        var nameRefused = false
        do {
            // The fingerprint of the text shown here: a change since it loaded is refused.
            struct SignReply: Decodable { let message: String? }
            let r: SignReply = try await api.call("sign_agreement", body: ["id": id, "version": a["version"] as? Int ?? 0, "agree": true,
                                                                        "signed_name": name.trimmingCharacters(in: .whitespaces),
                                                                        "text_hash": a["text_hash"] as? String ?? ""],
                                                  refusal: { reply in
                                                      nameRefused = ((reply["errors"] as? [String: Any])?["signed_name"]) != nil
                                                  })
            // 4.34.0: the access hold lifts at once after the last agreement (me's access_hold).
            await api.refreshMe()
            onSigned()
            // Said once this screen has closed: the pop moves VoiceOver, which cut it off.
            announceAfterDismiss(r.message ?? "Signed.")
            dismiss()
        } catch {
            busy = false
            // A refused name is about the Name field: by the server's errors.signed_name, or (a
            // server that sends no key) by its own name sentences; anything else goes to the summary.
            let said = error.localizedDescription
            let aboutName = nameRefused || Self.nameRefusals.contains { said.hasPrefix($0) }
            showFormError(said, in: &self.error, field: aboutName ? "Name" : nil)
            // Changed while open: load the new text, so it is read before signing.
            if error.localizedDescription.contains("changed while you had it open") { agree = false; await load() }
        }
    }
}

struct AgreementCopyView: View {
    @EnvironmentObject var api: API
    let id: Int
    @State private var copy: [String: Any]?
    @State private var error: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                if let error { ErrorBanner(message: error) }
                if let c = copy {
                    Text((c["title"] as? String ?? "Agreement") + ": your signed copy").font(.title2.weight(.semibold)).accessibilityAddTraits(.isHeader)
                    Text("Signed by \(c["signed_name"] as? String ?? "") on \(formatDateTime(c["signed_at"] as? String ?? "")), version \(c["version"] as? Int ?? 0). This is the text exactly as it read when you signed.")
                    // 4.36.0: small corrections made after signing, as the website says them.
                    if let corrections = c["corrections_text"] as? String, !corrections.isEmpty {
                        Text(corrections)
                    }
                    KBBlocksView(text: c["body"] as? String ?? "")
                } else if error == nil { ProgressView("Loading your signed copy…") }
            }.padding()
        }
        .navigationTitle("Signed copy")
        .navigationBarTitleDisplayMode(.inline)
        .task {
            do { copy = try await api.callDict("agreement_copy", query: ["id": String(id)])["copy"] as? [String: Any] }
            catch { self.error = error.localizedDescription }
        }
    }
}
